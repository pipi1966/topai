
import { MiningPackage, MiningPool, User } from './types';

export const PLATFORM_DOMAIN = "topminingcloud.work.gd";

export const PLATFORM_DNS = [
  "ns1.dnsExit.com",
  "ns2.dnsExit.com",
  "ns3.dnsExit.com",
  "ns4.dnsExit.com"
];

export const MINING_PACKAGES: MiningPackage[] = [
  {
    id: 'pkg-1',
    name: 'Antminer S9 - الإصدار الكلاسيكي',
    price: 10,
    durationDays: 15,
    dailyProfitPercent: 5.0,
    hashrate: '14 TH/s',
    icon: 'https://j.top4top.io/p_3669iibh30.jpg'
  },
  {
    id: 'pkg-2',
    name: 'Whatsminer M30S - الفئة المتوسطة',
    price: 30,
    durationDays: 30,
    dailyProfitPercent: 5.0,
    hashrate: '88 TH/s',
    icon: 'https://g.top4top.io/p_3669m1wfm0.jpg'
  },
  {
    id: 'pkg-3',
    name: 'GPU Rig - مصفوفة RTX 3090',
    price: 75,
    durationDays: 45,
    dailyProfitPercent: 5.0,
    hashrate: '1.2 GH/s',
    icon: 'https://i.top4top.io/p_3669ok5s40.jpg'
  },
  {
    id: 'pkg-4',
    name: 'Antminer S19 Pro - التعدين الاحترافي',
    price: 150,
    durationDays: 60,
    dailyProfitPercent: 5.0,
    hashrate: '110 TH/s',
    icon: 'https://j.top4top.io/p_3669iibh30.jpg'
  },
  {
    id: 'pkg-5',
    name: 'Mining Farm - وحدة تعدين مجمعة',
    price: 300,
    durationDays: 90,
    dailyProfitPercent: 5.0,
    hashrate: '500 TH/s',
    icon: 'https://j.top4top.io/p_36694c6wc0.jpg'
  },
  {
    id: 'pkg-6',
    name: 'Enterprise DC - مركز بيانات مؤسسي',
    price: 500,
    durationDays: 120,
    dailyProfitPercent: 5.0,
    hashrate: '2.5 PH/s',
    icon: 'https://b.top4top.io/p_3669h1s150.jpeg'
  }
];

export const MOCK_POOLS: MiningPool[] = [
  {
    id: 'pool-1',
    name: 'حوض العرب الذهبي',
    description: 'تجمع لأكبر المعدنين في المنطقة لتعظيم الأرباح اليومية.',
    totalHashrate: '2.5 PH/s',
    membersCount: 450,
    minEntryHashrate: 10,
    dailyPoolProfit: 1250,
    tags: ['عالي الأداء', 'موثوق']
  },
  {
    id: 'pool-2',
    name: 'تجمع النخبة الذكي',
    description: 'نظام توزيع آلي ذكي يعتمد على خوارزميات التعدين السريع.',
    totalHashrate: '1.8 PH/s',
    membersCount: 120,
    minEntryHashrate: 50,
    dailyPoolProfit: 980,
    tags: ['نخبة', 'سريع']
  }
];

export const INITIAL_USER: User = {
  id: 'u-001',
  email: 'user@example.com',
  balance: 0.00,
  totalDeposits: 0.00,
  totalEarnings: 0.00,
  referralCode: 'MINE-778',
  referralCount: 0,
  referralEarnings: 0.00,
  role: 'USER',
  activePackages: [],
  transactions: [],
  lastProfitUpdate: Date.now(),
  hasSeenOnboarding: false
};
