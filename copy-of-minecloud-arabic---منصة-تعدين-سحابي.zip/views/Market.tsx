
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MINING_PACKAGES } from '../constants';
import { 
  Zap, Cpu, ArrowRight, ArrowLeft,
  Loader2, CheckCircle2, AlertCircle, ShoppingBag, ArrowUpCircle,
  ShieldCheck, Server, CalendarDays
} from 'lucide-react';
import { MiningPackage } from '../types';
import { useUser } from '../UserContext';
import { useLanguage } from '../LanguageContext';

const Market = () => {
  const navigate = useNavigate();
  const { user, purchaseDevice, upgradeDevice } = useUser();
  const { t, isRtl } = useLanguage();
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [selectedPkg, setSelectedPkg] = useState<MiningPackage | null>(null);
  const [upgradeFromId, setUpgradeFromId] = useState<string | null>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAction = (pkg: MiningPackage) => {
    const upgradeableDevice = [...user.activePackages]
      .filter(p => {
        const basePkg = MINING_PACKAGES.find(mp => mp.id === p.packageId);
        return basePkg && basePkg.price < pkg.price;
      })
      .sort((a, b) => a.priceAtPurchase - b.priceAtPurchase)[0];

    setSelectedPkg(pkg);
    setUpgradeFromId(upgradeableDevice ? upgradeableDevice.instanceId : null);
    setError(null);
    setShowConfirmModal(true);
  };

  const confirmAction = async () => {
    if (!selectedPkg) return;
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 1500));

    let success = false;
    if (upgradeFromId) {
      success = upgradeDevice(upgradeFromId, selectedPkg);
    } else {
      success = purchaseDevice(selectedPkg);
    }

    if (success) {
      setIsProcessing(false);
      setShowConfirmModal(false);
      setShowSuccessModal(true);
    } else {
      setError(t('market.insufficient'));
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-5">
          <button onClick={() => navigate(-1)} className="p-3 glass rounded-2xl text-slate-400 hover:text-white transition-all border border-white/5">
            {isRtl ? <ArrowRight size={24} /> : <ArrowLeft size={24} />}
          </button>
          <div>
            <h1 className="text-4xl font-extrabold text-white tracking-tight">سوق معدات التعدين</h1>
            <p className="text-slate-400 font-medium mt-1">امتلك الآن أقوى أجهزة ASIC العالمية بصورها الحقيقية.</p>
          </div>
        </div>
      </header>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 pb-10">
        {MINING_PACKAGES.map((pkg) => {
          const ownedCount = user.activePackages.filter(p => p.packageId === pkg.id).length;
          const dailyProfit3Days = pkg.price * 0.02; 
          const dailyProfit7Days = pkg.price * 0.025;

          return (
            <div key={pkg.id} className="group relative glass rounded-[2.5rem] p-5 flex flex-col border transition-all duration-500 hover:-translate-y-3 border-slate-800 hover:border-blue-500/50 overflow-hidden shadow-2xl">
              {/* Image Container - Aspect Square and Optimized Display */}
              <div className="w-full aspect-square mb-6 rounded-[2rem] overflow-hidden relative shadow-2xl bg-slate-900 border border-white/5">
                <img 
                  src={pkg.icon} 
                  alt={pkg.name}
                  className="w-full h-full object-cover transition-transform duration-[2000ms] group-hover:scale-110" 
                  loading="lazy"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    if (target.src !== 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=800') {
                      target.src = 'https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=800';
                    }
                  }}
                />
                {/* Subtle Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/10 to-transparent"></div>
                
                <div className="absolute top-4 right-4 flex flex-col gap-2 items-end">
                  {ownedCount > 0 && (
                    <span className="bg-emerald-600/90 backdrop-blur-md text-white text-[10px] font-black px-3 py-1.5 rounded-full shadow-lg border border-emerald-400/30">
                      ممتلك ({ownedCount})
                    </span>
                  )}
                  <div className="flex items-center gap-1.5 bg-blue-600/90 backdrop-blur-md text-white text-[10px] font-black px-3 py-1.5 rounded-full border border-blue-400/30 shadow-lg">
                    <Server size={12} />
                    <span>هاردوير حقيقي</span>
                  </div>
                </div>
                
                <div className="absolute bottom-4 left-4 right-4">
                  <div className="glass bg-slate-900/60 backdrop-blur-xl p-4 rounded-2xl border border-white/10 flex items-center justify-between">
                    <div>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">سعر الوحدة</p>
                      <p className="text-2xl font-black text-white font-mono tracking-tighter tabular-nums font-mono">${pkg.price}</p>
                    </div>
                    <div className="p-3 bg-blue-600 rounded-xl text-white shadow-xl shadow-blue-600/30">
                      <Cpu size={22} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Details Section */}
              <div className="px-2 mb-6 space-y-4 flex-1">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-black text-white group-hover:text-blue-400 transition-colors leading-tight">{pkg.name}</h3>
                    <p className="text-[11px] text-slate-500 font-medium mt-1">معالج تعدين ASIC متطور</p>
                  </div>
                  <div className="flex items-center gap-1.5 text-blue-400 font-bold bg-blue-400/10 px-3 py-1.5 rounded-xl border border-blue-400/20">
                    <Zap size={14} className="fill-current" />
                    <span className="text-xs font-mono">{pkg.hashrate}</span>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-4 bg-slate-900/60 rounded-2xl border border-white/5 group-hover:bg-slate-900 transition-colors">
                    <div className="flex items-center gap-2 mb-1">
                       <CalendarDays size={12} className="text-slate-500" />
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">دورة 3 أيام</p>
                    </div>
                    <p className="text-sm font-black text-emerald-400 font-mono">+$ {(dailyProfit3Days * 3).toFixed(2)}</p>
                  </div>
                  <div className="p-4 bg-slate-900/60 rounded-2xl border border-white/5 group-hover:bg-slate-900 transition-colors">
                    <div className="flex items-center gap-2 mb-1">
                       <CalendarDays size={12} className="text-slate-500" />
                       <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tight">دورة 7 أيام</p>
                    </div>
                    <p className="text-sm font-black text-emerald-400 font-mono">+$ {(dailyProfit7Days * 7).toFixed(2)}</p>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => handleAction(pkg)} 
                className="w-full h-16 bg-blue-600 rounded-2xl font-black text-white shadow-xl hover:bg-blue-500 flex items-center justify-center gap-3 transition-all active:scale-95 group/btn overflow-hidden relative"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000"></div>
                {upgradeFromId ? (
                  <><ArrowUpCircle size={22} /> ترقية ملكية الجهاز</>
                ) : (
                  <><ShoppingBag size={22} /> اشتري الجهاز الآن</>
                )}
              </button>
            </div>
          );
        })}
      </div>

      {/* Confirmation Modal */}
      {showConfirmModal && selectedPkg && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-lg animate-in fade-in">
          <div className="glass w-full max-w-lg rounded-[3.5rem] p-1.5 shadow-2xl animate-in zoom-in-95">
            <div className="bg-slate-950/80 rounded-[3.4rem] p-10">
              <div className="flex justify-center mb-8">
                <div className="w-24 h-24 bg-blue-600/10 text-blue-500 rounded-[2rem] flex items-center justify-center border border-blue-500/20 shadow-inner">
                  <ShieldCheck size={48} />
                </div>
              </div>
              
              <h3 className="text-3xl font-black text-white mb-8 text-center">
                {upgradeFromId ? 'تأكيد الترقية' : 'تأكيد شراء المعدة'}
              </h3>
              
              <div className="p-8 bg-slate-900/60 rounded-[2.5rem] space-y-5 mb-8 border border-white/5">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-bold text-sm">الجهاز المختار:</span>
                  <span className="text-white font-black">{selectedPkg.name}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-400 font-bold text-sm">قدرة المعالجة:</span>
                  <span className="text-blue-400 font-black font-mono tracking-tighter">{selectedPkg.hashrate}</span>
                </div>
                <div className="flex justify-between pt-6 border-t border-slate-800">
                  <span className="text-white font-bold text-lg">المبلغ الإجمالي:</span>
                  <span className="text-emerald-400 font-black text-4xl font-mono tabular-nums font-mono">
                    ${(upgradeFromId 
                      ? selectedPkg.price - (user.activePackages.find(p => p.instanceId === upgradeFromId)?.priceAtPurchase || 0)
                      : selectedPkg.price).toFixed(2)}
                  </span>
                </div>
              </div>

              {error && (
                <div className="bg-rose-500/10 border border-rose-500/20 p-5 rounded-2xl text-rose-400 text-sm font-bold flex items-center gap-3 mb-6 animate-shake">
                  <AlertCircle size={20} /> {error}
                </div>
              )}

              <div className="flex gap-4">
                <button 
                  onClick={() => setShowConfirmModal(false)} 
                  className="flex-1 h-16 bg-slate-900 text-slate-400 rounded-2xl font-bold hover:text-white transition-all border border-slate-800"
                >
                  إلغاء
                </button>
                <button 
                  disabled={isProcessing} 
                  onClick={confirmAction} 
                  className="flex-1 h-16 bg-blue-600 text-white rounded-2xl font-black flex items-center justify-center gap-2 shadow-2xl shadow-blue-600/30 hover:bg-blue-500 transition-all"
                >
                  {isProcessing ? <Loader2 className="animate-spin" /> : 'تأكيد الشراء'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Success Modal */}
      {showSuccessModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-2xl animate-in fade-in">
          <div className="glass w-full max-w-sm rounded-[3rem] p-12 text-center animate-in zoom-in-95">
            <div className="w-28 h-28 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 border border-emerald-500/20 shadow-2xl shadow-emerald-500/10">
              <CheckCircle2 size={56} />
            </div>
            <h3 className="text-3xl font-black text-white mb-4">تم التفعيل!</h3>
            <p className="text-slate-400 mb-10 font-medium leading-relaxed">
              لقد أتممت عملية الاستحواذ على جهازك الجديد بنجاح. يمكنك الآن تفعيل أول دورة تعدين.
            </p>
            <button 
              onClick={() => navigate('/my-devices')} 
              className="w-full h-16 bg-emerald-600 text-white rounded-2xl font-black shadow-2xl shadow-emerald-600/30 hover:bg-emerald-500 transition-all"
            >
              انتقل إلى أجهزتي
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Market;
