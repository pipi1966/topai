
import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { 
  Wallet as WalletIcon, 
  History, 
  Copy, 
  CheckCircle2,
  Bitcoin,
  ArrowRight,
  ArrowLeft,
  Loader2,
  AlertTriangle,
  Info,
  TrendingUp,
  ArrowDownToLine,
  Gem,
  DollarSign,
  ChevronLeft,
  ChevronRight,
  Clock,
  ShieldCheck,
  Zap,
  ShieldAlert,
  HelpCircle
} from 'lucide-react';
import StatCard from '../components/StatCard';
import { useUser } from '../UserContext';
import { useLanguage } from '../LanguageContext';
import { TransactionStatus, TransactionType } from '../types';

const Wallet = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, withdrawFunds, depositFunds, totalEarningsPerSecond } = useUser();
  const { t, isRtl } = useLanguage();
  
  const initialTab = (location.state as any)?.tab || 'deposit';
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>(initialTab);
  
  const [copied, setCopied] = useState(false);
  const [amount, setAmount] = useState('');
  const [depositAmount, setDepositAmount] = useState('');
  const [address, setAddress] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccessModal, setShowSuccessModal] = useState(false);
  const [showDepositModal, setShowDepositModal] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if ((location.state as any)?.tab) {
      setActiveTab((location.state as any).tab);
    }
  }, [location.state]);

  const walletAddress = "TXLsHureixQs123XNcyzSWZ8edH6yTxS67";
  const pendingDeposits = user.transactions.filter(tx => tx.type === TransactionType.DEPOSIT && tx.status === TransactionStatus.PENDING);

  const handleCopy = () => {
    navigator.clipboard.writeText(walletAddress);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDepositConfirm = async () => {
    const dAmount = parseFloat(depositAmount);
    if (isNaN(dAmount) || dAmount <= 0) {
      setError(t('common.error'));
      return;
    }
    setError(null);
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    depositFunds(dAmount);
    setIsProcessing(false);
    setShowDepositModal(true);
    setDepositAmount('');
  };

  const handleWithdrawSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const withdrawAmount = parseFloat(amount);
    
    if (isNaN(withdrawAmount) || withdrawAmount < 5 || withdrawAmount > 20000) {
      setError(t('wallet.withdrawLimits'));
      return;
    }
    
    if (withdrawAmount > user.balance) {
      setError(t('wallet.insufficientWithdraw'));
      return;
    }
    
    setIsProcessing(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    const success = await withdrawFunds(withdrawAmount, address);
    if (success) {
      setIsProcessing(false);
      setShowSuccessModal(true);
      setAmount('');
      setAddress('');
    } else {
      setError(t('common.error'));
      setIsProcessing(false);
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex items-center gap-4">
        <button onClick={() => navigate(-1)} className="p-2.5 glass rounded-xl text-slate-400 hover:text-white transition-all active:scale-90">
          {isRtl ? <ArrowRight size={20} /> : <ArrowLeft size={20} />}
        </button>
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">{t('wallet.title')}</h1>
          <p className="text-slate-400">{t('wallet.subtitle')}</p>
        </div>
      </header>

      {/* العمليات المعلقة */}
      {pendingDeposits.length > 0 && (
        <div className="bg-amber-500/10 border border-amber-500/20 p-5 rounded-[2rem] flex items-center justify-between animate-pulse">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-amber-500/20 text-amber-500 rounded-2xl flex items-center justify-center">
              <Clock size={24} />
            </div>
            <div>
              <p className="font-black text-white text-sm">لديك إيداع بانتظار المراجعة</p>
              <p className="text-[10px] text-amber-400/80 font-medium">سيتم تحديث رصيدك فور تأكيد العملية من الإدارة.</p>
            </div>
          </div>
          <button onClick={() => navigate('/transactions')} className="bg-amber-600 text-white px-4 py-2 rounded-xl text-xs font-bold">عرض الطلب</button>
        </div>
      )}

      <div className="glass p-10 rounded-[2.5rem] relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-10">
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <span className="p-2.5 bg-blue-500/10 rounded-xl text-blue-500"><WalletIcon size={24} /></span>
              <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">{t('wallet.totalBalance')}</p>
            </div>
            <div className="flex items-baseline gap-2">
              <span className="text-blue-500 text-4xl font-bold">$</span>
              <h2 className="text-6xl md:text-7xl font-black text-white tracking-tighter tabular-nums font-mono">{user.balance.toFixed(2)}</h2>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4 w-full md:w-auto">
            <div className="glass bg-slate-800/20 p-5 rounded-2xl">
              <p className="text-slate-500 text-[10px] font-bold uppercase mb-2 flex items-center gap-1.5"><ArrowDownToLine size={12} className="text-blue-400" /> {t('wallet.totalDeposits')}</p>
              <p className="text-white font-mono font-bold text-lg">${user.totalDeposits.toFixed(2)}</p>
            </div>
            <div className="glass bg-slate-800/20 p-5 rounded-2xl">
              <p className="text-slate-500 text-[10px] font-bold uppercase mb-2 flex items-center gap-1.5"><Gem size={12} className="text-emerald-400" /> {t('wallet.miningEarnings')}</p>
              <p className="text-emerald-400 font-mono font-bold text-lg">${user.totalEarnings.toFixed(4)}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass rounded-3xl overflow-hidden flex flex-col">
          <div className="flex bg-slate-800/50 p-1.5 m-4 rounded-2xl">
            <button onClick={() => setActiveTab('deposit')} className={`flex-1 py-3.5 rounded-xl font-bold transition-all ${activeTab === 'deposit' ? 'bg-blue-600 text-white' : 'text-slate-400'}`}>{t('wallet.deposit')}</button>
            <button onClick={() => setActiveTab('withdraw')} className={`flex-1 py-3.5 rounded-xl font-bold transition-all ${activeTab === 'withdraw' ? 'bg-rose-600 text-white' : 'text-slate-400'}`}>{t('wallet.withdraw')}</button>
          </div>
          
          <div className="p-8">
            {activeTab === 'deposit' ? (
              <div className="space-y-6">
                <div className="bg-blue-500/10 p-5 rounded-2xl flex items-center gap-4 border border-blue-500/20">
                  <Bitcoin className="text-blue-400 shrink-0" size={32} />
                  <div>
                    <p className="font-bold text-white">{t('wallet.usdtDeposit')}</p>
                    <p className="text-xs text-blue-300/60 font-medium">{t('wallet.depositDesc')}</p>
                  </div>
                </div>
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-slate-400 flex items-center gap-2"><DollarSign size={14} className="text-blue-500" /> {t('wallet.depositAmount')}</label>
                    <input type="number" placeholder="0.00" value={depositAmount} onChange={(e) => setDepositAmount(e.target.value)} className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white font-bold" />
                  </div>
                  <div className="space-y-3">
                    <label className="text-sm font-bold text-slate-400">{t('wallet.walletAddress')}</label>
                    <div className="flex gap-2">
                      <input readOnly value={walletAddress} className="flex-1 bg-slate-900 border border-slate-800 p-4 rounded-xl text-blue-400 font-mono text-xs" />
                      <button onClick={handleCopy} className="p-4 bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white rounded-xl transition-all">
                        {copied ? <CheckCircle2 size={18} /> : <Copy size={18} />}
                      </button>
                    </div>
                  </div>
                </div>
                <button disabled={isProcessing} onClick={handleDepositConfirm} className="w-full py-4 bg-emerald-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-emerald-600/20">
                  {isProcessing ? <Loader2 className="animate-spin" /> : t('wallet.verifyDeposit')}
                </button>
              </div>
            ) : (
              <div className="space-y-8 animate-in fade-in slide-in-from-top-4">
                {/* شروط السحب البارزة */}
                <div className="bg-slate-900/50 rounded-[2rem] p-6 border border-white/5 relative overflow-hidden">
                  <div className="flex items-center gap-2 mb-6 text-rose-400">
                    <ShieldAlert size={20} />
                    <h4 className="text-sm font-black uppercase tracking-widest">شروط وقواعد السحب</h4>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div className="flex items-start gap-4 p-4 glass rounded-2xl border-white/5">
                      <div className="p-2.5 bg-rose-500/10 text-rose-500 rounded-xl"><DollarSign size={18}/></div>
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase">الحد الأدنى للسحب</p>
                        <p className="text-white font-black text-lg font-mono">$5.00</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4 p-4 glass rounded-2xl border-white/5">
                      <div className="p-2.5 bg-blue-500/10 text-blue-500 rounded-xl"><Zap size={18}/></div>
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase">الشبكة المدعومة</p>
                        <p className="text-blue-400 font-black text-sm font-mono">USDT (TRC20)</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4 p-4 glass rounded-2xl border-white/5">
                      <div className="p-2.5 bg-amber-500/10 text-amber-500 rounded-xl"><Clock size={18}/></div>
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase">وقت المعالجة</p>
                        <p className="text-white font-black text-sm">10-30 دقيقة</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-4 p-4 glass rounded-2xl border-white/5">
                      <div className="p-2.5 bg-emerald-500/10 text-emerald-500 rounded-xl"><HelpCircle size={18}/></div>
                      <div>
                        <p className="text-[10px] text-slate-500 font-bold uppercase">رسوم السحب</p>
                        <p className="text-emerald-400 font-black text-sm">0% (مجاناً)</p>
                      </div>
                    </div>
                  </div>
                </div>

                <form onSubmit={handleWithdrawSubmit} className="space-y-6">
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-bold text-slate-400 mb-2">المبلغ المطلوب سحبه ($)</label>
                      <input required type="number" step="0.01" value={amount} onChange={(e) => setAmount(e.target.value)} className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white font-bold" placeholder="0.00" />
                    </div>
                    <div>
                      <label className="block text-sm font-bold text-slate-400 mb-2">عنوان محفظتك (USDT TRC20)</label>
                      <input required type="text" value={address} onChange={(e) => setAddress(e.target.value)} className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white font-mono text-sm" placeholder="أدخل عنوان محفظتك" />
                    </div>
                  </div>
                  {error && <div className="bg-rose-500/10 p-4 rounded-xl text-rose-400 text-sm font-bold flex items-center gap-2 border border-rose-500/20 animate-shake"><AlertTriangle size={18} />{error}</div>}
                  <button disabled={isProcessing} className="w-full py-4 bg-rose-600 rounded-2xl font-bold shadow-rose-600/20 hover:bg-rose-500 transition-all flex items-center justify-center gap-2">
                    {isProcessing ? <Loader2 className="animate-spin" size={24} /> : 'تأكيد عملية السحب المباشر'}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <button onClick={() => navigate('/transactions')} className="w-full p-6 glass rounded-3xl flex items-center justify-between group hover:bg-blue-600/10 transition-all">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-blue-600/20 rounded-xl text-blue-400"><History size={24} /></div>
              <div><p className="font-bold text-white">{t('common.transactions')}</p></div>
            </div>
            {isRtl ? <ChevronLeft size={20} /> : <ChevronRight size={20} />}
          </button>
        </div>
      </div>

      {showDepositModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-2xl animate-in fade-in">
          <div className="glass w-full max-w-sm rounded-[3rem] p-12 text-center animate-in zoom-in-95">
            <div className="w-28 h-28 bg-blue-500/10 text-blue-500 rounded-full flex items-center justify-center mx-auto mb-8 border border-blue-500/20 relative">
              <Clock size={64} className="animate-pulse" />
            </div>
            <h3 className="text-3xl font-black text-white mb-4">تم إرسال الطلب</h3>
            <p className="text-slate-400 mb-10 leading-relaxed font-medium">سيتم مراجعة طلب الإيداع الخاص بك وإضافة المبلغ لمحفظتك فور التأكد.</p>
            <button onClick={() => setShowDepositModal(false)} className="w-full h-16 bg-blue-600 text-white rounded-2xl font-black">حسناً</button>
          </div>
        </div>
      )}

      {showSuccessModal && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-2xl animate-in fade-in">
          <div className="glass w-full max-w-sm rounded-[3rem] p-12 text-center animate-in zoom-in-95">
            <div className="w-28 h-28 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-8 border border-emerald-500/20">
              <CheckCircle2 size={64} />
            </div>
            <h3 className="text-3xl font-black text-white mb-4">طلب سحب ناجح</h3>
            <p className="text-slate-400 mb-10 leading-relaxed font-medium">تم استلام طلب السحب بنجاح وسيتم معالجته خلال 10-30 دقيقة.</p>
            <button onClick={() => setShowSuccessModal(false)} className="w-full h-16 bg-emerald-600 text-white rounded-2xl font-black">حسناً</button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Wallet;
