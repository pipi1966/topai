
import React from 'react';
import { Link } from 'react-router-dom';
import { MINING_PACKAGES } from '../constants';
import { Cpu, Zap, ShieldCheck, TrendingUp, ArrowLeft, ArrowRight, Users } from 'lucide-react';
import { useLanguage } from '../LanguageContext';

const Landing = () => {
  const { t, isRtl } = useLanguage();

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 selection:bg-blue-500/30">
      {/* Header */}
      <header className="p-6 md:px-12 flex justify-between items-center glass sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg shadow-blue-500/20">M</div>
          <span className="font-bold text-2xl">MineCloud</span>
        </div>
        <div className="flex gap-4">
          <Link to="/auth" className="px-6 py-2 rounded-lg font-bold hover:text-blue-400 transition-colors">
            {t('auth.login')}
          </Link>
          <Link to="/auth" className="px-6 py-2 bg-blue-600 text-white rounded-lg font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20">
            {t('landing.startNow')}
          </Link>
        </div>
      </header>

      {/* Hero */}
      <section className="relative py-20 px-6 md:px-12 text-center overflow-hidden">
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-blue-600/10 rounded-full blur-[120px] pointer-events-none"></div>
        <h1 className="text-4xl md:text-7xl font-extrabold mb-6 leading-tight">
          {t('landing.title').split(' ').map((word, i) => (
            word.includes('تعدين') || word.includes('Mining') || word.includes('minería') || word.includes('minage') 
            ? <span key={i} className="gradient-text"> {word} </span> 
            : <React.Fragment key={i}> {word} </React.Fragment>
          ))}
        </h1>
        <p className="text-slate-400 text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed">
          {t('landing.subtitle')}
        </p>
        <div className="flex flex-col sm:flex-row justify-center gap-4">
          <Link to="/auth" className="px-10 py-4 bg-blue-600 rounded-2xl text-lg font-bold hover:bg-blue-700 transition-all shadow-xl shadow-blue-600/30 flex items-center justify-center gap-2">
            {t('landing.startNow')} {isRtl ? <ArrowLeft size={20} /> : <ArrowRight size={20} />}
          </Link>
          <a href="#packages" className="px-10 py-4 glass rounded-2xl text-lg font-bold hover:bg-slate-800 transition-all flex items-center justify-center gap-2">
            {t('landing.viewPackages')}
          </a>
        </div>

        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
          {[
            { label: t('landing.stats.active'), val: '+50k', icon: Users },
            { label: t('landing.stats.paid'), val: '$12M', icon: TrendingUp },
            { label: t('landing.stats.hash'), val: '2.5 EH/s', icon: Zap },
            { label: t('landing.stats.withdraw'), val: '24/7', icon: ShieldCheck }
          ].map((stat, i) => (
            <div key={i} className="glass p-6 rounded-2xl group hover:border-blue-500/40 transition-all">
              <h3 className="text-2xl md:text-3xl font-bold mb-1 text-white">{stat.val}</h3>
              <p className="text-slate-500 text-sm font-medium">{stat.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Packages */}
      <section id="packages" className="py-24 px-6 md:px-12 bg-slate-900/50">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-5xl font-bold mb-4">{t('landing.viewPackages')}</h2>
            <p className="text-slate-400">{t('market.subtitle')}</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {MINING_PACKAGES.map((pkg) => (
              <div key={pkg.id} className="glass rounded-3xl p-8 relative overflow-hidden group hover:-translate-y-2 transition-all border border-slate-800 hover:border-blue-500/50">
                <div className="aspect-video mb-6 rounded-2xl overflow-hidden relative">
                  <img src={pkg.icon} alt={pkg.name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 to-transparent"></div>
                </div>
                <h3 className="text-2xl font-bold mb-2">{pkg.name}</h3>
                <div className="text-4xl font-bold text-blue-400 mb-6">${pkg.price}</div>
                
                <ul className="space-y-4 mb-8 text-slate-300">
                  <li className="flex items-center gap-2">
                    <ShieldCheck className="text-green-400" size={18} />
                    <span>{t('market.duration')}: {pkg.durationDays} {t('market.days')}</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <TrendingUp className="text-blue-400" size={18} />
                    <span>{t('market.dailyProfit')}: {pkg.dailyProfitPercent}%</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Zap className="text-yellow-400" size={18} />
                    <span>{t('market.power')}: {pkg.hashrate}</span>
                  </li>
                </ul>

                <Link to="/auth" className="w-full block text-center py-4 bg-slate-800 rounded-xl font-bold group-hover:bg-blue-600 transition-colors">
                  {t('market.rentNow')}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-slate-900 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-bold">M</div>
            <span className="font-bold text-xl">MineCloud</span>
          </div>
          <div className="flex gap-8 text-slate-500 text-sm">
            <a href="#" className="hover:text-blue-400 transition-colors">{t('support.title') || 'Support'}</a>
            <a href="#" className="hover:text-blue-400 transition-colors">Terms</a>
            <a href="#" className="hover:text-blue-400 transition-colors">Privacy</a>
          </div>
          <p className="text-slate-600 text-sm">© 2024 MineCloud. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
};

export default Landing;
