
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  ArrowLeft,
  Lock, 
  ShieldCheck, 
  Save, 
  Eye, 
  EyeOff,
  AlertCircle,
  CheckCircle2,
  Key,
  Smartphone,
  ShieldAlert,
  Languages,
  Copy,
  RefreshCw,
  Info
} from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import { useUser } from '../UserContext';

const Settings = () => {
  const navigate = useNavigate();
  const { language, setLanguage, t, isRtl } = useLanguage();
  const { exportAccount } = useUser();
  const [showPasswords, setShowPasswords] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const handleCopySyncCode = () => {
    const code = exportAccount();
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    if (error) setError(null);
  };

  const handlePasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (formData.newPassword.length < 8) {
      setError(language === 'ar' ? 'يجب أن تتكون كلمة المرور الجديدة من 8 أحرف على الأقل.' : 'New password must be at least 8 characters long.');
      return;
    }

    if (formData.newPassword !== formData.confirmPassword) {
      setError(language === 'ar' ? 'كلمة المرور الجديدة غير متطابقة مع التأكيد.' : 'Passwords do not match.');
      return;
    }

    setIsUpdating(true);
    await new Promise(resolve => setTimeout(resolve, 2000));
    setIsUpdating(false);
    setShowSuccess(true);
    setFormData({ currentPassword: '', newPassword: '', confirmPassword: '' });
  };

  const languages: { code: 'ar' | 'en' | 'es' | 'fr'; label: string }[] = [
    { code: 'ar', label: 'العربية' },
    { code: 'en', label: 'English' },
    { code: 'es', label: 'Español' },
    { code: 'fr', label: 'Français' }
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex items-center gap-4">
        <button 
          onClick={() => navigate(-1)} 
          className="p-2.5 glass rounded-xl text-slate-400 hover:text-white transition-all active:scale-90"
        >
          {isRtl ? <ArrowRight size={20} /> : <ArrowLeft size={20} />}
        </button>
        <div>
          <h1 className="text-3xl font-bold text-white mb-1">{t('settings.title')}</h1>
          <p className="text-slate-400">{t('settings.subtitle')}</p>
        </div>
      </header>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          
          {/* Cloud Sync / Backup Section - IMPORTANT FOR CROSS-BROWSER */}
          <div className="glass rounded-[2rem] overflow-hidden border-2 border-emerald-500/20 bg-emerald-500/5">
            <div className="p-8 border-b border-emerald-500/10 bg-emerald-500/10 flex items-center justify-between">
              <div className="flex items-center gap-3 text-emerald-400">
                <RefreshCw size={24} className="animate-spin-slow" />
                <h3 className="font-bold text-xl">المزامنة والوصول من أجهزة أخرى</h3>
              </div>
              <span className="text-[10px] font-black bg-emerald-500 text-white px-3 py-1 rounded-full uppercase">مفتاح الوصول السحابي</span>
            </div>
            <div className="p-8 space-y-6">
              <div className="flex items-start gap-4 bg-slate-900/50 p-6 rounded-2xl border border-white/5">
                <Info className="text-blue-400 shrink-0 mt-1" size={20} />
                <p className="text-sm text-slate-400 leading-relaxed">
                  هذا الكود هو "مفتاحك" للوصول إلى حسابك من أي متصفح أو هاتف آخر. انسخه واحفظه في مكان آمن. عند فتح المنصة في جهاز جديد، اختر <strong>"دخول من جهاز آخر"</strong> والصق هذا الكود.
                </p>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-black text-slate-500 uppercase tracking-widest mr-2">كود المزامنة الخاص بك</label>
                <div className="relative group">
                  <div className="w-full bg-slate-950 border border-slate-800 p-6 rounded-2xl text-blue-400 font-mono text-[9px] break-all leading-relaxed overflow-hidden max-h-32 blur-[2px] group-hover:blur-0 transition-all cursor-pointer select-all">
                    {exportAccount()}
                  </div>
                  <button 
                    onClick={handleCopySyncCode}
                    className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-blue-600 hover:bg-blue-500 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-2xl transition-all active:scale-95 z-20"
                  >
                    {copied ? <><CheckCircle2 size={18} /> تم النسخ!</> : <><Copy size={18} /> نسخ كود المزامنة</>}
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Language Selector Card */}
          <div className="glass rounded-[2rem] overflow-hidden border border-slate-800/50">
            <div className="p-8 border-b border-slate-800 bg-slate-900/30 flex items-center gap-3">
              <div className="p-3 bg-purple-600/20 text-purple-500 rounded-xl">
                <Languages size={20} />
              </div>
              <h3 className="font-bold text-xl text-white">{t('settings.languageTitle')}</h3>
            </div>
            <div className="p-8">
              <p className="text-slate-400 mb-6 text-sm">{t('settings.languageSubtitle')}</p>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {languages.map((lang) => (
                  <button 
                    key={lang.code}
                    onClick={() => setLanguage(lang.code)}
                    className={`p-4 rounded-2xl border font-bold transition-all ${
                      language === lang.code 
                        ? 'bg-blue-600 text-white border-blue-500 shadow-lg' 
                        : 'bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    {lang.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Password Change Card */}
          <div className="glass rounded-[2rem] overflow-hidden border border-slate-800/50">
            <div className="p-8 border-b border-slate-800 bg-slate-900/30 flex items-center gap-3">
              <div className="p-3 bg-blue-600/20 text-blue-500 rounded-xl">
                <Lock size={20} />
              </div>
              <h3 className="font-bold text-xl text-white">{t('settings.changePassword')}</h3>
            </div>

            <div className="p-8">
              <form onSubmit={handlePasswordChange} className="space-y-6">
                <div className="space-y-4">
                  <div className="relative">
                    <label className={`block text-sm font-bold text-slate-400 mb-2 ${isRtl ? 'mr-2' : 'ml-2'}`}>
                      {language === 'ar' ? 'كلمة المرور الحالية' : 'Current Password'}
                    </label>
                    <div className="relative">
                      <input 
                        required
                        type={showPasswords ? "text" : "password"}
                        name="currentPassword"
                        value={formData.currentPassword}
                        onChange={handleInputChange}
                        className={`w-full bg-slate-900 border border-slate-800 p-4 rounded-2xl text-white focus:border-blue-500 outline-none transition-all ${isRtl ? 'pl-12' : 'pr-12'}`}
                        placeholder="••••••••"
                      />
                      <button 
                        type="button"
                        onClick={() => setShowPasswords(!showPasswords)}
                        className={`absolute ${isRtl ? 'left-4' : 'right-4'} top-1/2 -translate-y-1/2 text-slate-500 hover:text-blue-400 transition-colors`}
                      >
                        {showPasswords ? <EyeOff size={20} /> : <Eye size={20} />}
                      </button>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-6 pt-2">
                    <div className="relative">
                      <label className={`block text-sm font-bold text-slate-400 mb-2 ${isRtl ? 'mr-2' : 'ml-2'}`}>
                        {language === 'ar' ? 'كلمة المرور الجديدة' : 'New Password'}
                      </label>
                      <input 
                        required
                        type={showPasswords ? "text" : "password"}
                        name="newPassword"
                        value={formData.newPassword}
                        onChange={handleInputChange}
                        className="w-full bg-slate-900 border border-slate-800 p-4 rounded-2xl text-white focus:border-blue-500 outline-none transition-all"
                        placeholder="••••••••"
                      />
                    </div>
                    <div className="relative">
                      <label className={`block text-sm font-bold text-slate-400 mb-2 ${isRtl ? 'mr-2' : 'ml-2'}`}>
                        {language === 'ar' ? 'تأكيد كلمة المرور' : 'Confirm Password'}
                      </label>
                      <input 
                        required
                        type={showPasswords ? "text" : "password"}
                        name="confirmPassword"
                        value={formData.confirmPassword}
                        onChange={handleInputChange}
                        className="w-full bg-slate-900 border border-slate-800 p-4 rounded-2xl text-white focus:border-blue-500 outline-none transition-all"
                        placeholder="••••••••"
                      />
                    </div>
                  </div>
                </div>

                {error && (
                  <div className="bg-rose-500/10 p-4 rounded-2xl text-rose-400 text-sm font-bold flex items-center gap-3 animate-shake border border-rose-500/20">
                    <AlertCircle size={18} />
                    {error}
                  </div>
                )}

                <div className="pt-4 flex flex-col md:flex-row items-center justify-between gap-4">
                  <p className="text-xs text-slate-500 max-w-[250px] leading-relaxed">
                    {t('settings.securityTip')}
                  </p>
                  <button 
                    disabled={isUpdating}
                    className="w-full md:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-xl shadow-blue-600/20 disabled:opacity-50"
                  >
                    {isUpdating ? t('common.loading') : <><Save size={20} /> {t('common.save')}</>}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="glass p-8 rounded-3xl border-l-4 border-l-emerald-500 bg-emerald-500/5">
            <div className="flex items-center gap-3 mb-6 text-emerald-400">
              <ShieldCheck size={24} />
              <h3 className="font-bold text-lg">{t('settings.securityStatus')}</h3>
            </div>
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-300 font-medium">قوة حماية الحساب</span>
                <span className="text-[10px] font-black bg-emerald-500 text-white px-2 py-1 rounded">آمن جداً</span>
              </div>
              <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div className="w-[85%] h-full bg-emerald-500 shadow-[0_0_10px_#10b981]"></div>
              </div>
            </div>
          </div>
          
          <div className="glass p-8 rounded-3xl bg-blue-500/5 border border-blue-500/10">
            <h4 className="font-bold text-blue-400 mb-2 flex items-center gap-2">
              <Smartphone size={18} />
              تطبيقات الجوال
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">قريباً: يمكنك تحميل تطبيقنا الرسمي على أجهزة Android و iOS لمتابعة أرباحك بضغطة زر.</p>
          </div>
        </div>
      </div>

      {showSuccess && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md animate-in fade-in duration-300">
          <div className="glass w-full max-w-sm rounded-[2.5rem] p-10 text-center shadow-2xl animate-in zoom-in-95">
            <div className="w-20 h-20 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 size={40} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">{t('common.success')}</h3>
            <p className="text-slate-400 mb-8 font-medium">تم تحديث إعداداتك بنجاح.</p>
            <button 
              onClick={() => setShowSuccess(false)} 
              className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-2xl font-bold transition-all"
            >
              موافق
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default Settings;
