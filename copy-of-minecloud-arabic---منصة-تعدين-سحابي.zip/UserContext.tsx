import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { INITIAL_USER, MINING_PACKAGES } from './constants';
import { User, MiningPackage, UserPackage, Transaction, TransactionType, TransactionStatus, DeviceStatus } from './types';

interface UserContextType {
  user: User;
  isAuthenticated: boolean;
  login: (email: string) => void;
  logout: () => void;
  purchaseDevice: (pkg: MiningPackage) => boolean;
  upgradeDevice: (instanceId: string, targetPkg: MiningPackage) => boolean;
  activateCycle: (instanceId: string, days: number, rate: number) => boolean;
  depositFunds: (amount: number) => void;
  withdrawFunds: (amount: number, address: string) => Promise<boolean>;
  approveTransaction: (txId: string) => void;
  rejectTransaction: (txId: string) => void;
  completeOnboarding: () => void;
  importAccount: (code: string) => boolean;
  exportAccount: () => string;
  totalEarningsPerSecond: number;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

const REGISTRY_KEY = 'minecloud_user_registry_v4';
const SESSION_KEY = 'minecloud_active_session_v4';

export const UserProvider: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return localStorage.getItem("isLoggedIn") === "true";
  });

  const [user, setUser] = useState<User>(() => {
    const activeEmail = (localStorage.getItem(SESSION_KEY) || "").trim().toLowerCase();
    if (activeEmail) {
      const registry = JSON.parse(localStorage.getItem(REGISTRY_KEY) || '{}');
      if (registry[activeEmail]) {
        return registry[activeEmail];
      }
    }
    return { ...INITIAL_USER, email: '', hasSeenOnboarding: false };
  });

  const totalEarningsPerSecond = user.activePackages.reduce((acc, pkg) => {
    if (pkg.status !== DeviceStatus.RUNNING || !pkg.currentDailyRate) return acc;
    return acc + ((pkg.priceAtPurchase * (pkg.currentDailyRate / 100)) / 86400);
  }, 0);

  const persistUser = useCallback((userData: User) => {
    if (!userData.email) return;
    const email = userData.email.trim().toLowerCase();
    const registry = JSON.parse(localStorage.getItem(REGISTRY_KEY) || '{}');
    registry[email] = userData;
    localStorage.setItem(REGISTRY_KEY, JSON.stringify(registry));
  }, []);

  useEffect(() => {
    if (isAuthenticated && user.email) {
      persistUser(user);
    }
  }, [user, isAuthenticated, persistUser]);

  useEffect(() => {
    if (!isAuthenticated || user.activePackages.length === 0) return;

    const engineInterval = setInterval(() => {
      setUser(prev => {
        const now = Date.now();
        let changed = false;
        let newBalance = prev.balance;
        let newTotalEarnings = prev.totalEarnings;

        const updatedPackages = prev.activePackages.map(pkg => {
          if (pkg.status === DeviceStatus.RUNNING && pkg.expiryDate && now >= pkg.expiryDate) {
            const profit = (pkg.priceAtPurchase * (pkg.currentDailyRate! / 100)) * pkg.currentDurationDays!;
            newBalance += profit;
            newTotalEarnings += profit;
            changed = true;
            return { 
              ...pkg, 
              status: DeviceStatus.IDLE, 
              expiryDate: undefined, 
              currentDurationDays: undefined, 
              currentDailyRate: undefined,
              dailyProfit: 0 
            };
          }
          return pkg;
        });

        if (!changed) return prev;
        return { ...prev, balance: newBalance, totalEarnings: newTotalEarnings, activePackages: updatedPackages };
      });
    }, 1000);

    return () => clearInterval(engineInterval);
  }, [isAuthenticated, user.activePackages.length]);

  const login = (email: string) => {
    const normalizedEmail = email.trim().toLowerCase();
    const registry = JSON.parse(localStorage.getItem(REGISTRY_KEY) || '{}');
    
    let currentUser: User;
    if (registry[normalizedEmail]) {
      currentUser = registry[normalizedEmail];
    } else {
      currentUser = { 
        ...INITIAL_USER, 
        id: `u-${Math.random().toString(36).substr(2, 9)}`,
        email: normalizedEmail, 
        hasSeenOnboarding: false,
        referralCode: `MINE-${Math.floor(100 + Math.random() * 899)}`
      };
      registry[normalizedEmail] = currentUser;
      localStorage.setItem(REGISTRY_KEY, JSON.stringify(registry));
    }
    
    localStorage.setItem(SESSION_KEY, normalizedEmail);
    localStorage.setItem("isLoggedIn", "true");
    setUser(currentUser);
    setIsAuthenticated(true);
  };

  const logout = () => {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("demoUser");
    setIsAuthenticated(false);
    setUser({ ...INITIAL_USER, email: '', hasSeenOnboarding: false });
  };

  const importAccount = (code: string): boolean => {
    try {
      const decodedData = JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(code), c => c.charCodeAt(0))));
      if (!decodedData.email || !decodedData.id) return false;
      
      const email = decodedData.email.trim().toLowerCase();
      const registry = JSON.parse(localStorage.getItem(REGISTRY_KEY) || '{}');
      registry[email] = decodedData;
      
      localStorage.setItem(REGISTRY_KEY, JSON.stringify(registry));
      localStorage.setItem(SESSION_KEY, email);
      localStorage.setItem("isLoggedIn", "true");
      
      setUser(decodedData);
      setIsAuthenticated(true);
      return true;
    } catch (e) {
      return false;
    }
  };

  const exportAccount = (): string => {
    try {
      const jsonStr = JSON.stringify(user);
      const bytes = new TextEncoder().encode(jsonStr);
      let binary = "";
      for (let i = 0; i < bytes.byteLength; i++) {
        binary += String.fromCharCode(bytes[i]);
      }
      return btoa(binary);
    } catch (e) {
      return "";
    }
  };

  const addTransaction = (amount: number, type: TransactionType, status = TransactionStatus.COMPLETED, address?: string): Transaction => ({
    id: `TX-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
    amount, type, status, date: new Date().toISOString(), currency: 'USDT', address
  });

  const purchaseDevice = (pkg: MiningPackage): boolean => {
    if (user.balance < pkg.price) return false;
    const tx = addTransaction(pkg.price, TransactionType.PURCHASE);
    const newOwnedPkg: UserPackage = {
      instanceId: `dev-${Date.now()}`,
      packageId: pkg.id,
      name: pkg.name,
      priceAtPurchase: pkg.price,
      status: DeviceStatus.IDLE,
      purchaseDate: Date.now(),
      isClaimed: false,
      icon: pkg.icon,
      dailyProfit: 0 
    };
    setUser(prev => ({
      ...prev,
      balance: prev.balance - pkg.price,
      activePackages: [newOwnedPkg, ...prev.activePackages],
      transactions: [tx, ...prev.transactions]
    }));
    return true;
  };

  const upgradeDevice = (instanceId: string, targetPkg: MiningPackage): boolean => {
    const device = user.activePackages.find(p => p.instanceId === instanceId);
    if (!device) return false;
    const upgradeCost = targetPkg.price - device.priceAtPurchase;
    if (user.balance < upgradeCost) return false;

    const tx = addTransaction(upgradeCost, TransactionType.UPGRADE);
    setUser(prev => ({
      ...prev,
      balance: prev.balance - upgradeCost,
      transactions: [tx, ...prev.transactions],
      activePackages: prev.activePackages.map(p => 
        p.instanceId === instanceId 
          ? { ...p, packageId: targetPkg.id, name: targetPkg.name, priceAtPurchase: targetPkg.price, icon: targetPkg.icon } 
          : p
      )
    }));
    return true;
  };

  const activateCycle = (instanceId: string, days: number, rate: number): boolean => {
    setUser(prev => ({
      ...prev,
      activePackages: prev.activePackages.map(p => {
        if (p.instanceId === instanceId && p.status === DeviceStatus.IDLE) {
          return {
            ...p,
            status: DeviceStatus.RUNNING,
            lastActivationDate: Date.now(),
            expiryDate: Date.now() + (days * 24 * 60 * 60 * 1000),
            currentDurationDays: days,
            currentDailyRate: rate,
            dailyProfit: p.priceAtPurchase * (rate / 100) 
          };
        }
        return p;
      })
    }));
    return true;
  };

  const depositFunds = (amount: number) => {
    const tx = addTransaction(amount, TransactionType.DEPOSIT, TransactionStatus.PENDING, "TXLsHureixQs123XNcyzSWZ8edH6yTxS67");
    setUser(prev => ({ ...prev, transactions: [tx, ...prev.transactions] }));
  };

  const withdrawFunds = async (amount: number, address: string) => {
    if (user.balance < amount) return false;
    const tx = addTransaction(amount, TransactionType.WITHDRAWAL, TransactionStatus.PENDING, address);
    setUser(prev => ({ ...prev, balance: prev.balance - amount, transactions: [tx, ...prev.transactions] }));
    return true;
  };

  const approveTransaction = (txId: string) => {
    setUser(prev => {
      const txIndex = prev.transactions.findIndex(t => t.id === txId);
      if (txIndex === -1) return prev;
      const tx = prev.transactions[txIndex];
      const newTransactions = [...prev.transactions];
      newTransactions[txIndex] = { ...tx, status: TransactionStatus.COMPLETED };
      let newBalance = prev.balance;
      let newTotalDeposits = prev.totalDeposits;
      if (tx.type === TransactionType.DEPOSIT) {
        newBalance += tx.amount;
        newTotalDeposits += tx.amount;
      }
      return { ...prev, balance: newBalance, totalDeposits: newTotalDeposits, transactions: newTransactions };
    });
  };

  const rejectTransaction = (txId: string) => {
    setUser(prev => {
      const txIndex = prev.transactions.findIndex(t => t.id === txId);
      if (txIndex === -1) return prev;
      const newTransactions = [...prev.transactions];
      newTransactions[txIndex] = { ...prev.transactions[txIndex], status: TransactionStatus.REJECTED };
      let newBalance = prev.balance;
      if (prev.transactions[txIndex].type === TransactionType.WITHDRAWAL) {
        newBalance += prev.transactions[txIndex].amount;
      }
      return { ...prev, balance: newBalance, transactions: newTransactions };
    });
  };

  const completeOnboarding = () => setUser(prev => ({ ...prev, hasSeenOnboarding: true }));

  return (
    <UserContext.Provider value={{ 
      user, isAuthenticated, login, logout, purchaseDevice, upgradeDevice, activateCycle,
      depositFunds, withdrawFunds, approveTransaction, rejectTransaction, 
      completeOnboarding, importAccount, exportAccount, totalEarningsPerSecond 
    }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => {
  const context = useContext(UserContext);
  if (context === undefined) throw new Error('useUser must be used within UserProvider');
  return context;
};