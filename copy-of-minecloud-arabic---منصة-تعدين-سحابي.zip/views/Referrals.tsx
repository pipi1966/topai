
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  UserPlus, 
  Gift, 
  Copy, 
  CheckCircle2, 
  ArrowRight, 
  ArrowLeft,
  TrendingUp,
  Share2,
  DollarSign,
  Info,
  ChevronLeft,
  ChevronRight,
  Award
} from 'lucide-react';
import StatCard from '../components/StatCard';
import { useUser } from '../UserContext';
import { useLanguage } from '../LanguageContext';

const Referrals = () => {
  const navigate = useNavigate();
  const { user } = useUser();
  const { t, isRtl } = useLanguage();
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(user.referralCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const referralSteps = [
    {
      icon: <Share2 className="text-blue-400" />,
      title: "شارك الرابط",
      desc: "أرسل كود الإحالة الخاص بك لأصدقائك أو شاركه على منصات التواصل الاجتماعي."
    },
    {
      icon: <UserPlus className="text-emerald-400" />,
      title: "تسجيل الأصدقاء",
      desc: "عندما يقوم صديقك بالتسجيل وشراء أول جهاز تعدين خاص به."
    },
    {
      icon: <Gift className="text-amber-400" />,
      title: "احصل على مكافأتك",
      desc: "ستحصل فوراً على عمولة بنسبة 5% من قيمة كل عملية شراء يقوم بها فريقك."
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate(-1)} 
            className="p-2.5 glass rounded-xl text-slate-400 hover:text-white transition-all active:scale-90"
          >
            {isRtl ? <ArrowRight size={20} /> : <ArrowLeft size={20} />}
          </button>
          <div>
            <h1 className="text-3xl font-black text-white mb-1">نظام الإحالات</h1>
            <p className="text-slate-400 font-medium">قم بدعوة أصدقائك وابنِ إمبراطورية التعدين الخاصة بك.</p>
          </div>
        </div>
      </header>

      {/* Referral Code Hero Section */}
      <div className="glass rounded-[2.5rem] p-1 border-emerald-500/20 shadow-2xl overflow-hidden relative group">
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px]"></div>
        <div className="bg-slate-950/60 rounded-[2.4rem] p-8 md:p-12 relative z-10">
          <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
            <div className="space-y-6 flex-1 text-center lg:text-right">
              <div className="inline-flex items-center gap-2 bg-emerald-500/10 text-emerald-400 px-4 py-2 rounded-full text-xs font-black border border-emerald-500/20">
                <Award size={16} />
                <span>برنامج شركاء MineCloud</span>
              </div>
              <h2 className="text-4xl md:text-5xl font-black text-white leading-tight">شارك النجاح، <br/><span className="text-emerald-500">ضاعف أرباحك!</span></h2>
              <p className="text-slate-400 max-w-lg leading-relaxed font-medium mx-auto lg:mx-0">
                برنامج الإحالات لدينا يتيح لك كسب عمولات فورية على كل عملية شراء يقوم بها الأشخاص الذين دعوتهم. لا يوجد حد أقصى للأرباح!
              </p>
            </div>

            <div className="w-full lg:w-auto">
              <div className="glass bg-slate-900/40 p-8 rounded-[2rem] border-white/5 space-y-6 min-w-[320px]">
                <p className="text-xs text-slate-500 font-black uppercase tracking-widest text-center">كود الإحالة الخاص بك</p>
                <div className="bg-slate-950 border border-slate-800 p-6 rounded-2xl flex items-center justify-between group/code transition-all hover:border-emerald-500/50">
                  <span className="text-3xl font-black text-white font-mono tracking-widest uppercase">{user.referralCode}</span>
                  <button 
                    onClick={handleCopy}
                    className={`p-3 rounded-xl transition-all ${copied ? 'bg-emerald-500 text-white' : 'bg-blue-600 text-white hover:bg-blue-500'}`}
                  >
                    {copied ? <CheckCircle2 size={24} /> : <Copy size={24} />}
                  </button>
                </div>
                {copied && (
                  <p className="text-center text-emerald-400 text-xs font-bold animate-in fade-in slide-in-from-top-2">تم نسخ الكود بنجاح!</p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard 
          label="إجمالي الإحالات" 
          value={user.referralCount} 
          icon={Users} 
          color="bg-blue-500"
          subValue="صديق منضم"
        />
        <StatCard 
          label="أرباح الإحالات" 
          value={`$${user.referralEarnings.toFixed(2)}`} 
          icon={DollarSign} 
          color="bg-emerald-500"
          subValue="رصيد مكتسب"
        />
        <StatCard 
          label="نسبة العمولة" 
          value="5%" 
          icon={TrendingUp} 
          color="bg-amber-500"
          subValue="على كل عملية شراء"
        />
      </div>

      {/* How it works */}
      <div className="grid lg:grid-cols-3 gap-6">
        {referralSteps.map((step, idx) => (
          <div key={idx} className="glass p-8 rounded-[2rem] border-white/5 hover:border-blue-500/30 transition-all text-center space-y-4">
            <div className="w-16 h-16 bg-slate-900 rounded-2xl flex items-center justify-center mx-auto text-3xl shadow-inner border border-white/5">
              {step.icon}
            </div>
            <h3 className="text-lg font-black text-white">{step.title}</h3>
            <p className="text-sm text-slate-400 font-medium leading-relaxed">{step.desc}</p>
          </div>
        ))}
      </div>

      {/* Referrals List Table */}
      <div className="glass rounded-[2rem] overflow-hidden border border-slate-800/50">
        <div className="p-8 border-b border-slate-800 bg-slate-900/30 flex justify-between items-center">
          <h3 className="font-bold text-xl flex items-center gap-3">
            <Users className="text-blue-500" size={24} />
            قائمة فريقك
          </h3>
          <span className="text-xs font-bold text-slate-500 bg-slate-800 px-4 py-1.5 rounded-full">آخر 20 إحالة</span>
        </div>
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-right">
            <thead>
              <tr className="bg-slate-900/50 text-slate-500 text-[10px] font-black uppercase tracking-widest border-b border-slate-800">
                <th className="px-8 py-6">المستخدم</th>
                <th className="px-8 py-6">تاريخ الانضمام</th>
                <th className="px-8 py-6 text-center">الحالة</th>
                <th className="px-8 py-6">العمولة المكتسبة</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {user.referralCount > 0 ? (
                // Mocking some referral data for visualization
                [...Array(user.referralCount)].map((_, i) => (
                  <tr key={i} className="hover:bg-white/[0.02] transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-slate-800 rounded-xl flex items-center justify-center font-black text-slate-400">
                          {String.fromCharCode(65 + i)}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white">user_{Math.random().toString(36).substring(7)}***</p>
                          <p className="text-[10px] text-slate-500 font-mono">ID: {Math.floor(1000 + Math.random() * 9000)}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-sm text-slate-400 font-medium">منذ {i + 1} أيام</td>
                    <td className="px-8 py-6 text-center">
                      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black bg-emerald-500/10 text-emerald-500 border border-emerald-500/20">
                        <CheckCircle2 size={12} /> نشط
                      </span>
                    </td>
                    <td className="px-8 py-6">
                      <span className="text-emerald-400 font-black font-mono">+$ {(Math.random() * 50).toFixed(2)}</span>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-8 py-24 text-center">
                    <div className="flex flex-col items-center opacity-30">
                      <UserPlus size={64} className="mb-4 text-slate-700" />
                      <p className="text-xl font-bold">لا توجد إحالات حتى الآن</p>
                      <p className="text-sm mt-1">ابدأ بمشاركة كود الإحالة الخاص بك لبناء فريقك.</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer Info */}
      <div className="bg-blue-600/5 border border-blue-500/10 p-6 rounded-3xl flex items-start gap-4">
        <Info className="text-blue-500 shrink-0 mt-1" size={24} />
        <div>
          <h4 className="font-bold text-blue-400 mb-1">معلومات هامة</h4>
          <p className="text-sm text-slate-400 leading-relaxed">
            يتم احتساب العمولات فقط عند قيام الصديق المدعو بشراء جهاز تعدين من السوق. تضاف الأرباح فوراً إلى رصيدك القابل للسحب. التلاعب بنظام الإحالات قد يؤدي إلى إيقاف الحساب نهائياً.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Referrals;
