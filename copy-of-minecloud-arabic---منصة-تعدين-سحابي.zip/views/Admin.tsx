
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Users, 
  Settings, 
  AlertCircle, 
  CheckCircle, 
  XCircle, 
  ShieldCheck,
  TrendingUp,
  CreditCard,
  Plus,
  ArrowRight,
  CheckCircle2,
  ArrowDownCircle,
  ArrowUpCircle,
  Clock,
  Wallet,
  Copy,
  Send,
  ExternalLink,
  Loader2,
  Globe,
  Network,
  Server,
  Activity
} from 'lucide-react';
import StatCard from '../components/StatCard';
import { useUser } from '../UserContext';
import { PLATFORM_DOMAIN, PLATFORM_DNS } from '../constants';
import { TransactionType, TransactionStatus } from '../types';

const Admin = () => {
  const navigate = useNavigate();
  const { user, approveTransaction, rejectTransaction } = useUser();
  const [copied, setCopied] = useState(false);
  const [processingId, setProcessingId] = useState<string | null>(null);
  
  const pendingDeposits = user.transactions.filter(t => t.type === TransactionType.DEPOSIT && t.status === TransactionStatus.PENDING);
  const pendingWithdrawals = user.transactions.filter(t => t.type === TransactionType.WITHDRAWAL && t.status === TransactionStatus.PENDING);

  const totalRevenue = user.transactions
    .filter(t => (t.type === TransactionType.PURCHASE || t.type === TransactionType.UPGRADE) && t.status === TransactionStatus.COMPLETED)
    .reduce((acc, curr) => acc + curr.amount, 0);

  const adminAddress = "TXLsHureixQs123XNcyzSWZ8edH6yTxS67";

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApproveWithdrawal = async (txId: string) => {
    setProcessingId(txId);
    await new Promise(resolve => setTimeout(resolve, 2000));
    approveTransaction(txId);
    setProcessingId(null);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2.5 glass hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all active:scale-90"
            title="رجوع"
          >
            <ArrowRight size={20} />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-white mb-1 flex items-center gap-3">
              <ShieldCheck className="text-blue-500" />
              لوحة الإدارة
            </h1>
            <p className="text-slate-400">تحكم كامل في النطاق {PLATFORM_DOMAIN} والمستخدمين.</p>
          </div>
        </div>
      </header>

      {/* Infrastructure Management Card */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="glass p-8 rounded-[2rem] border-l-4 border-l-blue-600 relative overflow-hidden">
          <div className="flex flex-col md:flex-row justify-between gap-8 relative z-10">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <div className="p-3 bg-blue-600/20 text-blue-400 rounded-2xl">
                  <Wallet size={24} />
                </div>
                <div>
                  <h3 className="text-lg font-black text-white">محفظة تحصيل الإيرادات</h3>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <code className="bg-slate-900 border border-slate-800 px-4 py-3 rounded-xl text-blue-400 font-mono text-sm flex-1">
                  {adminAddress}
                </code>
                <button onClick={() => handleCopy(adminAddress)} className="p-4 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-all">
                  {copied ? <CheckCircle2 size={20} className="text-emerald-500" /> : <Copy size={20} />}
                </button>
              </div>
            </div>
            <div className="bg-blue-600/10 p-6 rounded-3xl border border-blue-500/20 flex flex-col justify-center text-center md:text-right md:min-w-[200px]">
              <span className="text-xs text-blue-400 font-black uppercase tracking-widest mb-1">إجمالي الإيرادات</span>
              <span className="text-3xl font-black text-white font-mono tabular-nums">${totalRevenue.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <div className="glass p-8 rounded-[2rem] border-l-4 border-l-emerald-600">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-lg font-black text-white flex items-center gap-3">
              <Globe size={20} className="text-emerald-500" />
              إدارة النطاق والـ DNS
            </h3>
            <span className="text-[10px] font-black bg-emerald-500 text-white px-3 py-1 rounded-full uppercase">نشط</span>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-900/50 rounded-2xl border border-white/5">
              <span className="text-sm text-slate-400">النطاق الرئيسي</span>
              <span className="text-emerald-400 font-mono font-bold">{PLATFORM_DOMAIN}</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
               {PLATFORM_DNS.slice(0, 2).map((dns, i) => (
                 <div key={i} className="p-3 bg-slate-800/40 rounded-xl text-[10px] font-mono text-slate-500 border border-white/5">
                    {dns}
                 </div>
               ))}
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-4 gap-6">
        <StatCard label="المستخدمين" value="1,245" icon={Users} color="bg-blue-500" />
        <StatCard label="إجمالي الإيداعات" value={`$${user.totalDeposits.toFixed(2)}`} icon={CreditCard} color="bg-emerald-500" />
        <StatCard label="طلبات معلقة" value={pendingDeposits.length + pendingWithdrawals.length} icon={Clock} color="bg-rose-500" />
        <StatCard label="صافي الأرباح" value={`$${(totalRevenue * 0.15).toFixed(2)}`} icon={TrendingUp} color="bg-amber-500" />
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* طلبات الإيداع */}
        <div className="glass rounded-3xl overflow-hidden">
          <div className="p-6 border-b border-slate-800 flex justify-between items-center">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <ArrowDownCircle className="text-emerald-500" size={20} />
              طلبات إيداع بانتظار المراجعة
            </h3>
            <span className="bg-emerald-500/20 text-emerald-500 px-3 py-1 rounded-full text-xs font-bold">{pendingDeposits.length}</span>
          </div>
          <div className="divide-y divide-slate-800 min-h-[300px]">
            {pendingDeposits.length > 0 ? pendingDeposits.map(tx => (
              <div key={tx.id} className="p-6 hover:bg-slate-800/20 transition-all">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex gap-3">
                    <div className="w-10 h-10 rounded-full bg-emerald-900/40 text-emerald-500 flex items-center justify-center font-bold">D</div>
                    <div>
                      <h4 className="font-bold text-white">إيداع جديد</h4>
                      <p className="text-[10px] text-slate-500 font-mono">{tx.id}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-white">${tx.amount.toFixed(2)}</p>
                    <p className="text-[10px] text-slate-400">{new Date(tx.date).toLocaleDateString('ar-EG')}</p>
                  </div>
                </div>
                <div className="flex gap-3">
                  <button 
                    onClick={() => approveTransaction(tx.id)}
                    className="flex-1 py-2 bg-emerald-600/20 text-emerald-500 rounded-lg text-sm font-bold hover:bg-emerald-600 hover:text-white transition-all flex items-center justify-center gap-2"
                  >
                    <CheckCircle size={16} /> اعتماد المبلغ
                  </button>
                  <button 
                    onClick={() => rejectTransaction(tx.id)}
                    className="flex-1 py-2 bg-rose-600/20 text-rose-500 rounded-lg text-sm font-bold hover:bg-rose-600 hover:text-white transition-all flex items-center justify-center gap-2"
                  >
                    <XCircle size={16} /> رفض
                  </button>
                </div>
              </div>
            )) : (
              <div className="flex flex-col items-center justify-center py-20 opacity-50">
                <CheckCircle2 size={48} className="text-emerald-500 mb-4" />
                <p>لا توجد طلبات إيداع معلقة</p>
              </div>
            )}
          </div>
        </div>

        {/* طلبات السحب */}
        <div className="glass rounded-3xl overflow-hidden">
          <div className="p-6 border-b border-slate-800 flex justify-between items-center">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <ArrowUpCircle className="text-rose-500" size={20} />
              سحوبات بانتظار الموافقة
            </h3>
            <span className="bg-rose-500/20 text-rose-500 px-3 py-1 rounded-full text-xs font-bold">{pendingWithdrawals.length}</span>
          </div>
          <div className="divide-y divide-slate-800 min-h-[300px]">
            {pendingWithdrawals.length > 0 ? pendingWithdrawals.map(tx => (
              <div key={tx.id} className="p-6 hover:bg-slate-800/20 transition-all">
                <div className="flex justify-between items-start mb-3">
                  <div className="flex gap-3">
                    <div className="w-10 h-10 rounded-full bg-rose-900/40 text-rose-500 flex items-center justify-center font-bold">W</div>
                    <div>
                      <h4 className="font-bold text-white">طلب سحب</h4>
                      <p className="text-[10px] text-slate-500 font-mono">{tx.id}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-white">${tx.amount.toFixed(2)}</p>
                  </div>
                </div>

                <div className="bg-slate-900/60 p-3 rounded-xl mb-4 border border-slate-800 flex items-center justify-between">
                  <div className="flex items-center gap-2 overflow-hidden">
                    <Wallet size={14} className="text-rose-400 shrink-0" />
                    <span className="text-[10px] text-slate-400 font-mono truncate">{tx.address}</span>
                  </div>
                  <button onClick={() => handleCopy(tx.address || '')} className="p-1.5 hover:bg-slate-800 rounded text-slate-500 transition-all">
                    <Copy size={12} />
                  </button>
                </div>

                <div className="flex gap-3">
                  <button 
                    disabled={processingId === tx.id}
                    onClick={() => handleApproveWithdrawal(tx.id)}
                    className="flex-2 py-2.5 bg-emerald-600 text-white rounded-lg text-sm font-bold hover:bg-emerald-500 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/20"
                  >
                    {processingId === tx.id ? <Loader2 className="animate-spin" size={16} /> : <><Send size={16} /> اعتماد وإرسال</>}
                  </button>
                  <button 
                    disabled={processingId === tx.id}
                    onClick={() => rejectTransaction(tx.id)}
                    className="flex-1 py-2.5 bg-rose-600/20 text-rose-500 rounded-lg text-sm font-bold hover:bg-rose-600 hover:text-white transition-all flex items-center justify-center gap-2"
                  >
                    <XCircle size={16} /> رفض
                  </button>
                </div>
              </div>
            )) : (
              <div className="flex flex-col items-center justify-center py-20 opacity-50">
                <CheckCircle2 size={48} className="text-emerald-500 mb-4" />
                <p>لا توجد طلبات سحب معلقة</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;
