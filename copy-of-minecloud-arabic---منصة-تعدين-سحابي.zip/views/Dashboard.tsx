
import React from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  TrendingUp, 
  Wallet, 
  Cpu, 
  Clock, 
  ChevronLeft,
  ArrowUpRight,
  Zap,
  ArrowRight,
  ArrowLeft,
  Activity,
  LogIn,
  UserPlus,
  SendHorizontal,
  ExternalLink,
  Globe,
  Network,
  Server,
  Link2
} from 'lucide-react';
import StatCard from '../components/StatCard';
import { useUser } from '../UserContext';
import { useLanguage } from '../LanguageContext';
import { PLATFORM_DNS, PLATFORM_DOMAIN } from '../constants';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const mockChartData = [
  { name: '1', profit: 4.5 },
  { name: '2', profit: 5.2 },
  { name: '3', profit: 4.8 },
  { name: '4', profit: 6.1 },
  { name: '5', profit: 5.5 },
  { name: '6', profit: 7.2 },
  { name: '7', profit: 8.5 },
];

const Dashboard = () => {
  const navigate = useNavigate();
  const { user, totalEarningsPerSecond } = useUser();
  const { t, isRtl } = useLanguage();

  const totalDailyProfit = user.activePackages.reduce((acc, pkg) => acc + pkg.dailyProfit, 0);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      <header className="flex flex-col xl:flex-row xl:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={() => navigate(-1)}
            className="p-2.5 glass hover:bg-slate-800 rounded-xl text-slate-400 hover:text-white transition-all active:scale-90"
            title={t('common.back')}
          >
            {isRtl ? <ArrowRight size={20} /> : <ArrowLeft size={20} />}
          </button>
          <div>
            <h1 className="text-3xl font-bold text-white mb-1 font-cairo">{t('dashboard.title')}</h1>
            <p className="text-slate-400">{t('dashboard.subtitle')}</p>
          </div>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
          <button 
            onClick={() => navigate('/wallet', { state: { tab: 'deposit' } })}
            className="flex items-center gap-2 bg-blue-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-blue-600/20 hover:bg-blue-700 transition-all active:scale-95"
          >
            <Wallet size={18} />
            {t('wallet.deposit')}
          </button>
          <button 
            onClick={() => navigate('/wallet', { state: { tab: 'withdraw' } })}
            className="flex items-center gap-2 bg-rose-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-rose-600/20 hover:bg-rose-700 transition-all active:scale-95"
          >
            <ArrowUpRight size={18} />
            {t('wallet.withdraw')}
          </button>
        </div>
      </header>

      {/* Domain Status Banner */}
      <div className="glass p-5 rounded-3xl border border-emerald-500/20 bg-emerald-500/5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-emerald-500 rounded-lg text-white">
            <Globe size={18} />
          </div>
          <div>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">النطاق الرسمي المتصل</p>
            <p className="text-emerald-400 font-mono font-bold">{PLATFORM_DOMAIN}</p>
          </div>
        </div>
        <div className="flex items-center gap-2 text-[10px] font-black bg-emerald-500/10 text-emerald-500 px-3 py-1.5 rounded-full border border-emerald-500/20">
          <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
          متصل ومحمي
        </div>
      </div>

      {/* Real-time Balance Display */}
      <div className="glass p-8 md:p-12 rounded-[2.5rem] border-b-4 border-b-blue-600 relative overflow-hidden group">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-blue-500/50 to-transparent"></div>
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-10">
          <div className="space-y-6 flex-1">
            <div className="flex items-center gap-3">
              <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">{t('dashboard.balance')}</p>
              {user.activePackages.length > 0 && (
                <span className="flex items-center gap-1.5 bg-emerald-500/10 text-emerald-400 px-3 py-1 rounded-full text-[10px] font-black animate-pulse border border-emerald-500/20">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                  {t('dashboard.live')}
                </span>
              )}
            </div>
            
            <div className="flex flex-col md:flex-row md:items-center gap-8">
              <div className="flex items-baseline gap-2">
                <span className="text-blue-500 text-4xl font-bold">$</span>
                <h2 className="text-5xl md:text-7xl font-black text-white tracking-tighter tabular-nums font-mono">
                  {user.balance.toFixed(2)}
                </h2>
              </div>
            </div>
          </div>
          
          <div className="grid grid-cols-2 gap-4">
            <div className="glass bg-slate-800/40 px-6 py-5 rounded-3xl border-slate-700/50 group-hover:border-blue-500/30 transition-all">
              <p className="text-slate-500 text-[10px] font-bold uppercase mb-1">{t('dashboard.perSecond')}</p>
              <p className="text-emerald-400 font-mono font-bold text-lg">
                +${totalEarningsPerSecond.toFixed(8)}
              </p>
            </div>
            <div className="glass bg-slate-800/40 px-6 py-5 rounded-3xl border-slate-700/50 group-hover:border-blue-500/30 transition-all">
              <p className="text-slate-500 text-[10px] font-bold uppercase mb-1">{t('dashboard.totalHash')}</p>
              <p className="text-blue-400 font-bold text-lg">
                {user.activePackages.length * 25} <span className="text-xs">TH/s</span>
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        <StatCard 
          label={t('dashboard.dailyProfit')} 
          value={`$${totalDailyProfit.toFixed(2)}`} 
          icon={TrendingUp} 
          color="bg-emerald-500"
          subValue={t('dashboard.stable')}
        />
        <StatCard 
          label={t('dashboard.activeDevices')} 
          value={user.activePackages.length} 
          icon={Cpu} 
          color="bg-purple-500"
        />
        <StatCard 
          label={t('dashboard.systemStatus')} 
          value={t('dashboard.stable')} 
          icon={Activity} 
          color="bg-blue-500"
          subValue={t('dashboard.serversEfficient')}
        />
      </div>

      {/* Infrastructure DNS Status */}
      <div className="glass p-8 rounded-[2rem] border-l-4 border-l-emerald-500 bg-emerald-500/5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl">
              <Network size={28} />
            </div>
            <div>
              <h3 className="text-xl font-black text-white font-cairo">عقد الاتصال بالشبكة (DNS)</h3>
              <p className="text-slate-400 text-sm font-medium">حالة الربط بين النطاق الرئيسي وخوادم التعدين</p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1 lg:flex-none">
            {PLATFORM_DNS.map((dns, idx) => (
              <div key={idx} className="bg-slate-900/60 border border-slate-800 px-4 py-3 rounded-xl flex items-center justify-between group hover:border-emerald-500/30 transition-all">
                <code className="text-emerald-400 font-mono text-[10px]">{dns}</code>
                <div className="flex items-center gap-1">
                  <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                  <span className="text-[9px] text-slate-500 font-bold">CONNECTED</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass p-6 rounded-2xl">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-bold flex items-center gap-2 font-cairo">
              <TrendingUp className="text-blue-400" />
              {t('dashboard.performance')}
            </h3>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={mockChartData}>
                <defs>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="name" stroke="#64748b" />
                <YAxis stroke="#64748b" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#fff' }}
                />
                <Area type="monotone" dataKey="profit" stroke="#3b82f6" fillOpacity={1} fill="url(#colorProfit)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass p-6 rounded-2xl flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <h3 className="text-xl font-bold flex items-center gap-2 font-cairo">
              <Cpu className="text-purple-400" />
              {t('dashboard.activeEquip')}
            </h3>
          </div>
          <div className="space-y-4 overflow-y-auto max-h-64 flex-1 pr-1 custom-scrollbar">
            {user.activePackages.length > 0 ? user.activePackages.map((pkg) => (
              <div key={pkg.instanceId} className="p-3 bg-slate-900/40 rounded-xl border border-slate-800 hover:border-blue-500/30 transition-all relative overflow-hidden group">
                <div className="flex items-center gap-4">
                  <img src={pkg.icon} className="w-12 h-12 rounded-lg object-cover border border-slate-700 shadow-sm" alt={pkg.name} />
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start">
                      <h4 className="font-bold text-white text-sm truncate font-cairo">{pkg.name}</h4>
                      <span className="text-[10px] text-slate-500 font-mono">#{pkg.instanceId.slice(-4)}</span>
                    </div>
                  </div>
                </div>
              </div>
            )) : (
              <div className="flex-1 flex flex-col items-center justify-center text-center p-6 opacity-30">
                <div className="w-16 h-16 bg-slate-800 rounded-full flex items-center justify-center mb-4">
                  <Zap size={32} />
                </div>
              </div>
            )}
          </div>
          <button onClick={() => navigate('/market')} className="mt-6 w-full py-4 bg-blue-600/10 hover:bg-blue-600 text-blue-400 hover:text-white rounded-2xl font-bold flex items-center justify-center gap-2 transition-all border border-blue-500/20">
            {t('dashboard.discover')} {isRtl ? <ChevronLeft size={16} /> : <ArrowRight size={16} />}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
