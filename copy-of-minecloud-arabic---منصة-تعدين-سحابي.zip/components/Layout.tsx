import React, { useState, useLayoutEffect, useRef } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Wallet, 
  Users, 
  Settings as SettingsIcon, 
  LogOut, 
  Menu, 
  X,
  ShieldAlert,
  Home,
  History,
  Headset,
  Languages,
  Cpu,
  SendHorizontal,
  UsersRound,
  ArrowRight,
  ArrowLeft
} from 'lucide-react';
import { useLanguage } from '../LanguageContext';
import { useUser } from '../UserContext';

interface LayoutProps {
  children?: React.ReactNode;
  userRole: 'USER' | 'ADMIN';
}

const Layout: React.FC<LayoutProps> = ({ children, userRole }) => {
  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const { language, setLanguage, t, isRtl } = useLanguage();
  const { logout } = useUser();
  const location = useLocation();
  const navigate = useNavigate();
  const mainContentRef = useRef<HTMLElement>(null);

  useLayoutEffect(() => {
    if (mainContentRef.current) {
      mainContentRef.current.scrollTop = 0;
    }
  }, [location.pathname]);

  const menuItems = [
    { name: t('common.dashboard'), path: '/dashboard', icon: LayoutDashboard, role: 'USER' },
    { name: t('common.market'), path: '/market', icon: ShoppingCart, role: 'USER' },
    { name: t('common.myDevices'), path: '/my-devices', icon: Cpu, role: 'USER' },
    { name: t('common.pools'), path: '/pools', icon: UsersRound, role: 'USER' },
    { name: t('common.wallet'), path: '/wallet', icon: Wallet, role: 'USER' },
    { name: t('common.transactions'), path: '/transactions', icon: History, role: 'USER' },
    { name: t('common.referrals'), path: '/referrals', icon: Users, role: 'USER' },
    { name: t('common.support'), path: '/support', icon: Headset, role: 'USER' },
    { name: t('common.settings'), path: '/settings', icon: SettingsIcon, role: 'USER' },
    { name: t('common.admin'), path: '/admin', icon: ShieldAlert, role: 'ADMIN' },
  ].filter(item => item.role === 'USER' || (item.role === 'ADMIN' && userRole === 'ADMIN'));

  const toggleLanguage = () => {
    const langs: ('ar' | 'en' | 'es' | 'fr')[] = ['ar', 'en', 'es', 'fr'];
    const currentIndex = langs.indexOf(language);
    const nextIndex = (currentIndex + 1) % langs.length;
    setLanguage(langs[nextIndex]);
  };

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const getLangLabel = () => {
    switch (language) {
      case 'ar': return 'English';
      case 'en': return 'Español';
      case 'es': return 'Français';
      case 'fr': return 'العربية';
      default: return 'Language';
    }
  };

  return (
    <div className={`min-h-screen bg-slate-950 flex flex-col md:flex-row overflow-hidden ${isRtl ? 'text-right' : 'text-left'}`}>
      {/* Mobile Header */}
      <div className="md:hidden flex items-center justify-between p-4 glass sticky top-0 z-50">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-blue-600 rounded flex items-center justify-center text-white font-bold">M</div>
          <span className="font-bold text-xl tracking-tight text-white font-cairo">MineCloud</span>
        </div>
        <button onClick={() => setSidebarOpen(!isSidebarOpen)} className="text-white">
          {isSidebarOpen ? <X /> : <Menu />}
        </button>
      </div>

      {/* Sidebar */}
      <aside className={`
        fixed inset-0 z-40 md:relative md:z-auto
        w-64 glass transform transition-transform duration-300 ease-in-out
        ${isSidebarOpen 
          ? 'translate-x-0' 
          : (isRtl ? 'translate-x-full' : '-translate-x-full') + ' md:translate-x-0'
        }
      `}>
        <div className="h-full flex flex-col p-6">
          <div className="hidden md:flex items-center gap-3 mb-10">
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center text-white font-bold text-2xl shadow-lg shadow-blue-500/20">M</div>
            <span className="font-bold text-2xl text-white font-cairo">MineCloud</span>
          </div>

          <nav className="flex-1 space-y-2 overflow-y-auto custom-scrollbar">
            <Link 
              to="/dashboard" 
              className={`flex items-center gap-3 p-3 rounded-lg transition-all ${location.pathname === '/dashboard' || location.pathname === '/' ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30 font-bold' : 'text-slate-400 hover:bg-slate-800 hover:text-white'}`}
              onClick={() => setSidebarOpen(false)}
            >
              <Home size={20} />
              <span className="font-medium">{t('sidebar.home')}</span>
            </Link>
            {menuItems.filter(i => i.path !== '/dashboard').map((item) => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  className={`flex items-center gap-3 p-3 rounded-lg transition-all ${
                    isActive 
                      ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30 font-bold' 
                      : 'text-slate-400 hover:bg-slate-800 hover:text-white'
                  }`}
                  onClick={() => setSidebarOpen(false)}
                >
                  <Icon size={20} />
                  <span>{item.name}</span>
                </Link>
              );
            })}
          </nav>

          <div className="mt-auto pt-6 border-t border-slate-800 space-y-2">
            <a 
              href="https://t.me/Miningcloud2" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 w-full rounded-lg text-blue-400 bg-blue-400/5 hover:bg-blue-400/10 border border-blue-400/10 transition-all font-bold"
            >
              <SendHorizontal size={20} />
              <span>قناة التلغرام</span>
            </a>
            <button 
              onClick={toggleLanguage}
              className="flex items-center gap-3 p-3 w-full rounded-lg text-slate-400 hover:bg-slate-800 hover:text-white transition-colors"
            >
              <Languages size={20} />
              <span>{getLangLabel()}</span>
            </button>
            <button 
              onClick={handleLogout}
              className="flex items-center gap-3 p-3 w-full rounded-lg text-rose-400 hover:bg-rose-500/10 transition-colors"
            >
              <LogOut size={20} />
              <span>{t('common.logout')}</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main 
        id="main-scroll-container"
        ref={mainContentRef}
        className="flex-1 p-4 md:p-8 overflow-y-auto h-screen custom-scrollbar"
      >
        <div className="max-w-6xl mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
};

export default Layout;