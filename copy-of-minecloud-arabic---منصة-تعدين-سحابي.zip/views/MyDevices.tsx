
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Cpu, Zap, TrendingUp, Activity, Clock, ArrowRight, ArrowLeft,
  CheckCircle2, Calendar, PlayCircle, Timer, AlertCircle, Loader2
} from 'lucide-react';
import { useUser } from '../UserContext';
import { useLanguage } from '../LanguageContext';
import { UserPackage, DeviceStatus } from '../types';

const DeviceCard: React.FC<{ pkg: UserPackage }> = ({ pkg }) => {
  const { activateCycle } = useUser();
  const { t, isRtl } = useLanguage();
  const [timeLeft, setTimeLeft] = useState("");
  const [progress, setProgress] = useState(0);
  const [showActivateModal, setShowActivateModal] = useState(false);
  const [activating, setActivating] = useState(false);

  useEffect(() => {
    if (pkg.status !== DeviceStatus.RUNNING || !pkg.expiryDate || !pkg.lastActivationDate) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const total = pkg.expiryDate! - pkg.lastActivationDate!;
      const remaining = pkg.expiryDate! - now;

      if (remaining <= 0) {
        setTimeLeft(isRtl ? "مكتمل" : "Completed");
        setProgress(100);
        clearInterval(interval);
      } else {
        const days = Math.floor(remaining / (1000 * 60 * 60 * 24));
        const hours = Math.floor((remaining % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const mins = Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60));
        const secs = Math.floor((remaining % (1000 * 60)) / 1000);
        setTimeLeft(`${days}d ${hours}h ${mins}m ${secs}s`);
        setProgress(((total - remaining) / total) * 100);
      }
    }, 1000);
    return () => clearInterval(interval);
  }, [pkg, isRtl]);

  const handleStart = async (days: number, rate: number) => {
    setActivating(true);
    await new Promise(r => setTimeout(r, 1000));
    activateCycle(pkg.instanceId, days, rate);
    setActivating(false);
    setShowActivateModal(false);
  };

  return (
    <div className={`glass rounded-[2rem] p-6 border transition-all group relative overflow-hidden ${pkg.status === DeviceStatus.IDLE ? 'border-dashed border-slate-700' : 'border-slate-800'}`}>
      <div className="flex justify-between items-start mb-6">
        <div className="flex gap-4">
          <div className="w-16 h-16 rounded-2xl overflow-hidden relative border border-white/5">
            <img src={pkg.icon} className="w-full h-full object-cover" />
            <div className={`absolute inset-0 ${pkg.status === DeviceStatus.RUNNING ? 'bg-blue-600/20 animate-pulse' : 'bg-slate-900/40'}`}></div>
          </div>
          <div>
            <h3 className="text-xl font-bold text-white">{pkg.name}</h3>
            <span className={`text-[10px] font-black px-2 py-0.5 rounded-full ${pkg.status === DeviceStatus.RUNNING ? 'bg-emerald-500 text-white' : 'bg-slate-800 text-slate-500'}`}>
              {pkg.status === DeviceStatus.RUNNING ? 'قيد التعدين' : 'متوقف'}
            </span>
          </div>
        </div>
      </div>

      {pkg.status === DeviceStatus.RUNNING ? (
        <div className="space-y-4">
          <div className="flex justify-between text-[11px] font-bold">
            <span className="text-slate-400">الوقت المتبقي:</span>
            <span className="text-blue-400 font-mono">{timeLeft}</span>
          </div>
          <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden">
            <div className="h-full bg-blue-600 transition-all duration-1000" style={{ width: `${progress}%` }}></div>
          </div>
          <p className="text-[10px] text-slate-500 text-center">سيتم إيداع الأرباح تلقائياً فور انتهاء العداد.</p>
        </div>
      ) : (
        <button onClick={() => setShowActivateModal(true)} className="w-full h-14 bg-emerald-600/10 hover:bg-emerald-600 text-emerald-400 hover:text-white rounded-xl font-bold flex items-center justify-center gap-2 transition-all">
          <PlayCircle size={20} /> بدء دورة تشغيل جديدة
        </button>
      )}

      {showActivateModal && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center p-4 bg-slate-950/95 backdrop-blur-md animate-in fade-in">
          <div className="glass w-full max-w-sm rounded-[2.5rem] p-8 animate-in zoom-in-95">
            <h4 className="text-xl font-black text-white mb-6 text-center">اختر مدة التشغيل</h4>
            <div className="space-y-4">
              <button onClick={() => handleStart(3, 2)} className="w-full p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500 flex justify-between items-center group transition-all">
                <div className="text-right">
                  <p className="font-bold text-white">تشغيل لمدة 3 أيام</p>
                  <p className="text-xs text-blue-400">ربح 2% يومياً</p>
                </div>
                <ArrowRight size={20} className="text-slate-600 group-hover:text-blue-400" />
              </button>
              <button onClick={() => handleStart(7, 2.5)} className="w-full p-5 rounded-2xl bg-slate-900 border border-slate-800 hover:border-blue-500 flex justify-between items-center group transition-all">
                <div className="text-right">
                  <p className="font-bold text-white">تشغيل لمدة 7 أيام</p>
                  <p className="text-xs text-blue-400">ربح 2.5% يومياً</p>
                </div>
                <ArrowRight size={20} className="text-slate-600 group-hover:text-blue-400" />
              </button>
              <button onClick={() => setShowActivateModal(false)} className="w-full py-3 text-slate-500 font-bold text-sm">إلغاء</button>
            </div>
            {activating && <div className="mt-4 flex justify-center"><Loader2 className="animate-spin text-blue-500" /></div>}
          </div>
        </div>
      )}
    </div>
  );
};

const MyDevices = () => {
  const navigate = useNavigate();
  const { user } = useUser();
  const { t, isRtl } = useLanguage();

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <header className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate(-1)} className="p-3 glass rounded-xl text-slate-400 hover:text-white transition-all">
            {isRtl ? <ArrowRight size={20} /> : <ArrowLeft size={20} />}
          </button>
          <h1 className="text-3xl font-extrabold text-white">أجهزتي المملوكة</h1>
        </div>
      </header>

      {user.activePackages.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {user.activePackages.map((pkg) => <DeviceCard key={pkg.instanceId} pkg={pkg} />)}
        </div>
      ) : (
        <div className="glass p-20 rounded-[3rem] text-center border-dashed border-2 border-slate-800">
          <Cpu size={48} className="mx-auto text-slate-700 mb-4" />
          <h3 className="text-xl font-bold text-slate-400 mb-6">لا تمتلك أي أجهزة تعدين حالياً</h3>
          <button onClick={() => navigate('/market')} className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold">تسوّق الآن</button>
        </div>
      )}
    </div>
  );
};

export default MyDevices;
