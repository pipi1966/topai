
export enum TransactionStatus {
  PENDING = 'PENDING',
  COMPLETED = 'COMPLETED',
  REJECTED = 'REJECTED'
}

export enum TransactionType {
  DEPOSIT = 'DEPOSIT',
  WITHDRAWAL = 'WITHDRAWAL',
  EARNING = 'EARNING',
  PURCHASE = 'PURCHASE',
  UPGRADE = 'UPGRADE'
}

export enum DeviceStatus {
  IDLE = 'IDLE',
  RUNNING = 'RUNNING',
  COMPLETED = 'COMPLETED'
}

export interface MiningPackage {
  id: string;
  name: string;
  price: number;
  durationDays: number;
  dailyProfitPercent: number;
  hashrate: string;
  icon: string;
}

export interface MiningPool {
  id: string;
  name: string;
  description: string;
  totalHashrate: string;
  membersCount: number;
  minEntryHashrate: number;
  dailyPoolProfit: number;
  tags: string[];
}

export interface UserPackage {
  instanceId: string;
  packageId: string;
  name: string;
  priceAtPurchase: number; 
  status: DeviceStatus;
  purchaseDate: number; 
  lastActivationDate?: number;
  expiryDate?: number; 
  currentDurationDays?: number;
  currentDailyRate?: number;
  isClaimed: boolean; 
  icon: string;
  dailyProfit: number;
}

export interface Transaction {
  id: string;
  amount: number;
  type: TransactionType;
  status: TransactionStatus;
  date: string;
  currency: string;
  address?: string; // أضفنا هذا الحقل لتتبع عنوان المحفظة (للسحب والإيداع)
}

export interface User {
  id: string;
  email: string;
  balance: number;
  totalDeposits: number;
  totalEarnings: number;
  referralCode: string;
  referralCount: number;
  referralEarnings: number;
  role: 'USER' | 'ADMIN';
  activePackages: UserPackage[];
  transactions: Transaction[];
  lastProfitUpdate: number;
  hasSeenOnboarding: boolean;
}
