
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ArrowRight, 
  Headset, 
  Send, 
  Mail, 
  MessageSquare, 
  MessageCircle, 
  ChevronDown, 
  ExternalLink,
  CheckCircle2,
  Clock,
  HelpCircle,
  ShieldCheck,
  SendHorizontal,
  Server,
  Network
} from 'lucide-react';
import { PLATFORM_DNS } from '../constants';

const faqs = [
  {
    question: "كيف أبدأ التعدين في المنصة؟",
    answer: "عليك أولاً إيداع رصيد في محفظتك عبر USDT (TRC20)، ثم التوجه إلى سوق المعدات واختيار الباقة التي تناسبك وتفعيلها بضغطة زر."
  },
  {
    question: "كم تستغرق عملية السحب؟",
    answer: "تتم معالجة طلبات السحب عادةً في غضون 10 إلى 30 دقيقة، وفي حالات نادرة قد تستغرق 24 ساعة كحد أقصى للتدقيق الأمني."
  },
  {
    question: "ما هو الحد الأدنى للإيداع والسحب؟",
    answer: "الحد الأدنى للإيداع هو 10 دولار، والحد الأدنى للسحب هو 5 دولار أمريكي."
  },
  {
    question: "هل يمكنني تشغيل أكثر من باقة في وقت واحد؟",
    answer: "نعم، يمكنك استئجار وتشغيل عدد غير محدود من الباقات في نفس الوقت، وستتراكم الأرباح جميعها في رصيدك الموحد."
  }
];

const Support = () => {
  const navigate = useNavigate();
  const [formStatus, setFormStatus] = useState<'idle' | 'sending' | 'success'>('idle');
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('sending');
    setTimeout(() => setFormStatus('success'), 1500);
  };

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <header className="flex items-center gap-4">
        <button 
          onClick={() => navigate(-1)} 
          className="p-2.5 glass rounded-xl text-slate-400 hover:text-white transition-all active:scale-90"
        >
          <ArrowRight size={20} />
        </button>
        <div>
          <h1 className="text-3xl font-bold text-white mb-1 font-cairo">الدعم الفني</h1>
          <p className="text-slate-400">نحن هنا لمساعدتك على مدار الساعة في أي استفسار يخص حسابك.</p>
        </div>
      </header>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Contact Methods Cards */}
        <div className="lg:col-span-2 space-y-8">
          <div className="grid md:grid-cols-3 gap-4">
            <a href="https://t.me/Miningcloud2" target="_blank" rel="noopener noreferrer" className="glass p-6 rounded-2xl flex flex-col items-center text-center group hover:border-blue-500/50 transition-all border-blue-500/10">
              <div className="p-3 bg-blue-500/10 text-blue-400 rounded-xl mb-4 group-hover:scale-110 transition-transform">
                <SendHorizontal size={24} />
              </div>
              <p className="font-bold text-white text-sm font-cairo">قناة التلغرام</p>
              <p className="text-[10px] text-slate-500 mt-1">@Miningcloud2</p>
            </a>
            <a href="https://wa.me/minecloud" target="_blank" className="glass p-6 rounded-2xl flex flex-col items-center text-center group hover:border-emerald-500/50 transition-all">
              <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl mb-4 group-hover:scale-110 transition-transform">
                <MessageCircle size={24} />
              </div>
              <p className="font-bold text-white text-sm font-cairo">واتساب</p>
              <p className="text-[10px] text-slate-500 mt-1">دعم مباشر</p>
            </a>
            <a href="mailto:support@minecloud.app" className="glass p-6 rounded-2xl flex flex-col items-center text-center group hover:border-purple-500/50 transition-all">
              <div className="p-3 bg-purple-500/10 text-purple-400 rounded-xl mb-4 group-hover:scale-110 transition-transform">
                <Mail size={24} />
              </div>
              <p className="font-bold text-white text-sm font-cairo">البريد الإلكتروني</p>
              <p className="text-[10px] text-slate-500 mt-1">للحالات الرسمية</p>
            </a>
          </div>

          {/* Contact Form */}
          <div className="glass rounded-[2rem] overflow-hidden">
            <div className="p-8 border-b border-slate-800 bg-slate-900/30 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-blue-600/20 text-blue-500 rounded-full flex items-center justify-center">
                  <Headset size={20} />
                </div>
                <h3 className="font-bold text-xl font-cairo">أرسل لنا رسالة</h3>
              </div>
              <div className="flex items-center gap-2 text-[10px] font-black text-emerald-400 uppercase tracking-widest bg-emerald-500/10 px-3 py-1.5 rounded-full border border-emerald-500/20">
                <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></div>
                متصل الآن
              </div>
            </div>

            <div className="p-8">
              {formStatus === 'success' ? (
                <div className="py-12 text-center animate-in zoom-in duration-500">
                  <div className="w-20 h-20 bg-emerald-500/20 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 size={40} />
                  </div>
                  <h4 className="text-2xl font-bold text-white mb-2 font-cairo">تم إرسال رسالتك!</h4>
                  <p className="text-slate-400 mb-8 max-w-xs mx-auto">لقد استلمنا استفسارك وسيقوم أحد أعضاء فريق الدعم بالرد عليك قريباً.</p>
                  <button 
                    onClick={() => setFormStatus('idle')}
                    className="px-8 py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl font-bold transition-all"
                  >
                    إرسال رسالة أخرى
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-400 mr-2">الموضوع</label>
                      <select className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white focus:border-blue-500 outline-none transition-all appearance-none cursor-pointer">
                        <option>استفسار عن إيداع</option>
                        <option>مشكلة في السحب</option>
                        <option>تفعيل باقة تعدين</option>
                        <option>أخرى</option>
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-bold text-slate-400 mr-2">رقم الحساب أو الهاتف</label>
                      <input required type="text" placeholder="أدخل رقمك للتواصل" className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white focus:border-blue-500 outline-none transition-all" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-400 mr-2">تفاصيل الرسالة</label>
                    <textarea required rows={5} placeholder="اشرح لنا بالتفصيل ما الذي يمكننا مساعدتك فيه..." className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white focus:border-blue-500 outline-none transition-all resize-none"></textarea>
                  </div>
                  <button 
                    disabled={formStatus === 'sending'}
                    className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-bold text-lg shadow-xl shadow-blue-600/20 flex items-center justify-center gap-3 transition-all active:scale-[0.98] disabled:opacity-50"
                  >
                    {formStatus === 'sending' ? 'جاري الإرسال...' : <><Send size={20} /> إرسال الرسالة للمراجعة</>}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        {/* Sidebar / FAQs */}
        <div className="space-y-6">
          <div className="glass p-8 rounded-3xl border-l-4 border-l-blue-600">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2 font-cairo">
              <HelpCircle className="text-blue-500" />
              الأسئلة الشائعة
            </h3>
            <div className="space-y-4">
              {faqs.map((faq, idx) => (
                <div key={idx} className="border-b border-slate-800 pb-4 last:border-0">
                  <button 
                    onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                    className="w-full flex items-center justify-between text-right gap-4 group"
                  >
                    <span className={`text-sm font-bold transition-colors ${openFaq === idx ? 'text-blue-400' : 'text-slate-200 group-hover:text-white'}`}>
                      {faq.question}
                    </span>
                    <ChevronDown size={18} className={`text-slate-500 transition-transform ${openFaq === idx ? 'rotate-180 text-blue-400' : ''}`} />
                  </button>
                  {openFaq === idx && (
                    <p className="mt-3 text-xs text-slate-400 leading-relaxed animate-in slide-in-from-top-2 duration-300">
                      {faq.answer}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>

          <div className="glass p-8 rounded-3xl bg-blue-500/5 border border-blue-500/10">
            <div className="flex items-center gap-3 mb-4 text-blue-400">
              <Network size={20} />
              <h4 className="font-bold font-cairo">معلومات المزامنة</h4>
            </div>
            <div className="space-y-2">
              <p className="text-[10px] text-slate-500 font-bold uppercase">عناوين DNS المعتمدة:</p>
              {PLATFORM_DNS.map((dns, i) => (
                <div key={i} className="text-xs font-mono text-blue-400/70 border-b border-white/5 pb-1">{dns}</div>
              ))}
            </div>
          </div>

          <div className="glass p-8 rounded-3xl bg-emerald-500/5 border border-emerald-500/10">
            <div className="flex items-center gap-3 mb-4 text-emerald-400">
              <Clock size={20} />
              <h4 className="font-bold font-cairo">أوقات العمل</h4>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">
              فريق الدعم الفني متواجد لخدمتك <span className="text-emerald-400 font-bold">24/7</span> طوال أيام الأسبوع بما في ذلك أيام العطل.
            </p>
          </div>

          <div className="glass p-8 rounded-3xl bg-blue-500/5 border border-blue-500/10">
            <div className="flex items-center gap-3 mb-4 text-blue-400">
              <ShieldCheck size={20} />
              <h4 className="font-bold font-cairo">ضمان الخصوصية</h4>
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">
              جميع محادثاتك مع الدعم مشفرة بالكامل ولا يتم مشاركتها مع أي أطراف ثالثة.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Support;
