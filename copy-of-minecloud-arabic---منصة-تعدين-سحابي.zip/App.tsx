import React, { useState } from 'react';
import { Routes, Route, Navigate, useNavigate } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './views/Dashboard';
import Market from './views/Market';
import MyDevices from './views/MyDevices';
import Pools from './views/Pools';
import Wallet from './views/Wallet';
import Admin from './views/Admin';
import Transactions from './views/Transactions';
import Referrals from './views/Referrals';
import Support from './views/Support';
import Settings from './views/Settings';
import { UserProvider, useUser } from './UserContext';
import { LanguageProvider, useLanguage } from './LanguageContext';
import { Loader2, AlertCircle, Eye, EyeOff, ArrowRight, Zap, TrendingUp, FileText, UserCircle } from 'lucide-react';

const OnboardingModal = () => {
  const { completeOnboarding } = useUser();
  const [step, setStep] = useState(1);

  const steps = [
    {
      title: "اتفاقية الملكية الدائمة",
      desc: "بموجب هذا العقد، فإن أي جهاز تعدين يتم شراؤه يصبح ملكية خاصة للمستخدم للأبد. لا تنتهي صلاحية الجهاز أبداً، ويمكنك استخدامه لتوليد الأرباح بشكل مستمر دون الحاجة لإعادة الشراء.",
      icon: <FileText className="text-blue-400" size={48} />
    },
    {
      title: "نظام التفعيل والتشغيل الدوري",
      desc: "يجب على المستخدم تفعيل دورات التشغيل يدوياً عند انتهاء كل دورة. يمكنك الاختيار بين دورة 3 أيام (ربح 2% يومياً) أو دورة 7 أيام (ربح 2.5% يومياً). يتم صرف الأرباح مع رأس مال التشغيل تلقائياً بنهاية كل دورة.",
      icon: <Zap className="text-yellow-400" size={48} />
    },
    {
      title: "حق الترقية بفرق السعر",
      desc: "تمنح المنصة المستخدم الحق في ترقية أجهزته إلى مستويات أعلى في أي وقت. عند الترقية، ستقوم فقط بدفع 'فرق السعر' بين جهازك الحالي والجهاز الجديد، مع انتقال كافة صلاحيات الملكية للجهاز الأعلى فوراً.",
      icon: <TrendingUp className="text-emerald-400" size={48} />
    }
  ];

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-slate-950/98 backdrop-blur-xl animate-in fade-in">
      <div className="glass w-full max-w-md rounded-[3rem] p-10 text-center relative overflow-hidden shadow-2xl border border-blue-500/20 font-cairo">
        <div className="absolute top-0 left-0 w-full h-1.5 bg-slate-800">
          <div className="h-full bg-blue-600 transition-all duration-500 shadow-[0_0_10px_#2563eb]" style={{ width: `${(step/3)*100}%` }}></div>
        </div>
        
        <div className="mb-8 flex justify-center scale-110">{steps[step-1].icon}</div>
        <h3 className="text-2xl font-black text-white mb-4 tracking-tight leading-tight">{steps[step-1].title}</h3>
        <p className="text-slate-400 mb-10 leading-relaxed text-sm font-semibold">{steps[step-1].desc}</p>
        
        <div className="space-y-3">
          <button 
            onClick={() => step < 3 ? setStep(step + 1) : completeOnboarding()}
            className="w-full h-16 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl font-black text-lg flex items-center justify-center gap-2 group transition-all"
          >
            {step < 3 ? 'موافقة ومتابعة' : 'أوافق على كافة الشروط'} <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
          </button>
          {step > 1 && (
            <button onClick={() => setStep(step - 1)} className="text-slate-500 text-sm font-bold hover:text-white transition-colors">السابق</button>
          )}
        </div>
      </div>
    </div>
  );
};

const AuthView = () => {
  const navigate = useNavigate();
  const [authMode, setAuthMode] = useState<'login' | 'register' | 'sync'>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [syncCode, setSyncCode] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const { login, importAccount } = useUser();
  const { t, isRtl } = useLanguage();

  const handleLoginSuccess = (userEmail: string) => {
    login(userEmail);
    navigate('/dashboard', { replace: true });
  };

  const handleDemoLogin = () => {
    handleLoginSuccess("demo@demo.com");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setIsLoading(true);

    if (authMode === 'sync') {
      const success = importAccount(syncCode);
      if (success) {
        navigate('/dashboard', { replace: true });
      } else {
        setError(isRtl ? 'كود المزامنة غير صحيح' : 'Invalid sync code');
      }
      setIsLoading(false);
      return;
    }

    const normalizedEmail = email.trim().toLowerCase();
    if (authMode === 'register' && password !== confirmPassword) {
      setError(isRtl ? 'كلمتا المرور غير متطابقتين' : 'Passwords do not match');
      setIsLoading(false);
      return;
    }

    await new Promise(resolve => setTimeout(resolve, 800));
    handleLoginSuccess(normalizedEmail);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-slate-950 relative overflow-hidden font-cairo">
      <div className="glass w-full max-w-md p-10 rounded-3xl space-y-8 relative z-10 shadow-2xl border border-white/5">
        <div className="text-center">
          <div className="w-16 h-16 bg-blue-600 rounded-2xl mx-auto flex items-center justify-center text-white font-bold text-3xl mb-4">M</div>
          <h2 className="text-3xl font-bold text-white font-cairo">
            {authMode === 'login' ? t('auth.login') : authMode === 'register' ? t('auth.register') : 'استرداد الحساب'}
          </h2>
        </div>

        {error && <div className="bg-rose-500/10 border border-rose-500/20 p-4 rounded-xl text-rose-400 text-xs font-bold flex items-center gap-3"><AlertCircle size={18} />{error}</div>}

        <form className="space-y-4" onSubmit={handleSubmit}>
          {authMode !== 'sync' && (
            <>
              <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="البريد الإلكتروني" className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-blue-500" />
              <div className="relative">
                <input required type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="كلمة المرور" className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-blue-500" />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white">
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
              {authMode === 'register' && (
                <input required type={showPassword ? "text" : "password"} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="تأكيد كلمة المرور" className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-white outline-none focus:border-blue-500" />
              )}
            </>
          )}
          {authMode === 'sync' && (
            <textarea required value={syncCode} onChange={(e) => setSyncCode(e.target.value)} placeholder="الصق كود المزامنة هنا..." className="w-full bg-slate-900 border border-slate-800 p-4 rounded-xl text-blue-400 font-mono text-[10px] outline-none h-32 resize-none" />
          )}
          <button disabled={isLoading} className="w-full py-4 rounded-2xl font-bold text-lg bg-blue-600 hover:bg-blue-700 text-white shadow-xl transition-all">
            {isLoading ? <Loader2 className="animate-spin mx-auto" /> : (authMode === 'login' ? 'دخول' : 'إنشاء')}
          </button>
        </form>

        <button onClick={handleDemoLogin} className="w-full py-3 bg-slate-900/50 border border-slate-800 text-slate-400 hover:text-emerald-400 rounded-2xl text-sm font-bold flex items-center justify-center gap-2">
          <UserCircle size={18} /> دخول تجريبي (Demo)
        </button>

        <div className="text-center pt-4">
          <button onClick={() => setAuthMode(authMode === 'login' ? 'register' : 'login')} className="text-slate-500 hover:text-blue-400 text-sm font-bold">
            {authMode === 'login' ? t('auth.noAccount') : t('auth.hasAccount')}
          </button>
        </div>
      </div>
    </div>
  );
};

const ProtectedRoute: React.FC<{ children?: React.ReactNode }> = ({ children }) => {
  const { isAuthenticated } = useUser();
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <>{children}</>;
};

const AppContent: React.FC = () => {
  const { user, isAuthenticated } = useUser();

  return (
    <div className="antialiased text-slate-100 selection:bg-blue-500/30">
      {isAuthenticated && !user.hasSeenOnboarding && <OnboardingModal />}
      
      <Routes>
        <Route path="/login" element={isAuthenticated ? <Navigate to="/dashboard" replace /> : <AuthView />} />
        
        <Route path="/dashboard" element={<ProtectedRoute><Layout userRole={user.role}><Dashboard /></Layout></ProtectedRoute>} />
        <Route path="/market" element={<ProtectedRoute><Layout userRole={user.role}><Market /></Layout></ProtectedRoute>} />
        <Route path="/my-devices" element={<ProtectedRoute><Layout userRole={user.role}><MyDevices /></Layout></ProtectedRoute>} />
        <Route path="/pools" element={<ProtectedRoute><Layout userRole={user.role}><Pools /></Layout></ProtectedRoute>} />
        <Route path="/wallet" element={<ProtectedRoute><Layout userRole={user.role}><Wallet /></Layout></ProtectedRoute>} />
        <Route path="/transactions" element={<ProtectedRoute><Layout userRole={user.role}><Transactions /></Layout></ProtectedRoute>} />
        <Route path="/referrals" element={<ProtectedRoute><Layout userRole={user.role}><Referrals /></Layout></ProtectedRoute>} />
        <Route path="/support" element={<ProtectedRoute><Layout userRole={user.role}><Support /></Layout></ProtectedRoute>} />
        <Route path="/settings" element={<ProtectedRoute><Layout userRole={user.role}><Settings /></Layout></ProtectedRoute>} />
        
        {user.role === 'ADMIN' && (
          <Route path="/admin" element={<ProtectedRoute><Layout userRole={user.role}><Admin /></Layout></ProtectedRoute>} />
        )}

        <Route path="/" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} />
        <Route path="*" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} />
      </Routes>
    </div>
  );
};

const App: React.FC = () => (
  <LanguageProvider>
    <UserProvider>
      <AppContent />
    </UserProvider>
  </LanguageProvider>
);

export default App;